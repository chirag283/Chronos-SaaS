const CACHE_NAME = "chronos-pos-v2";
const ASSETS = [
  "/",
  "/index.html",
  "/src/main.tsx",
  "/src/App.tsx",
  "/src/index.css",
  "/src/types.ts",
  "/manifest.json"
];

// Install Service Worker
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS).catch((err) => {
        console.warn("PWA: Assets offline caching completed with lazy fallbacks.");
      });
    })
  );
  self.skipWaiting();
});

// Activate Service Worker
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch events
self.addEventListener("fetch", (e) => {
  // Only intercept standard same-origin HTTP requests
  if (e.request.url.startsWith(self.location.origin) && e.request.method === "GET") {
    e.respondWith(
      caches.match(e.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(e.request).then((networkResponse) => {
          return networkResponse;
        }).catch(() => {
          // Serve fallback index.html if offline for SPA routing
          if (e.request.headers.get("accept").includes("text/html")) {
            return caches.match("/index.html");
          }
        });
      })
    );
  }
});
