export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
  unit: string;
  label?: string | null;
  sku: string;
  imageUrl?: string | null;
  createdAt?: string;
  // Advanced tracking fields
  warehouse?: string | null;
  serialNumber?: string | null;
  variants?: string[] | null;
  expiryDate?: string | null;
  minStock?: number | null;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
  imeiOrSerial?: string;
}

export interface TransactionItem {
  id: number;
  transactionId: number;
  productId: number;
  productName: string;
  quantity: number;
  price: number;
  selectedVariant?: string;
  imeiOrSerial?: string;
  taxAmount?: number;
}

export interface Transaction {
  id: number;
  userUid?: string | null;
  operatorId?: string | null;
  customerName: string;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: string;
  paymentStatus: string;
  createdAt: string;
  items?: TransactionItem[];
  // Advanced finance features
  splitDetails?: string | null;
  emiTerm?: number | null;
  downPayment?: number | null;
  outstandingBalance?: number | null;
  invoiceNumber?: string;
  taxAmount?: number;
}
