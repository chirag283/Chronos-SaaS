import ECommerceFrame from "./components/ECommerceFrame.tsx";

export default function App() {
  return <ECommerceFrame />;
}
