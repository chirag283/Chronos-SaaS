import { db } from "./index.ts";
import {
  businesses,
  users,
  categories,
  suppliers,
  products,
  customers,
  transactions,
  transactionItems,
  expenses,
  employees,
  inventoryLogs,
} from "./schema.ts";
import { eq, and, desc } from "drizzle-orm";

// ==========================================
// BUSINESS (TENANT) MANAGEMENT
// ==========================================

export async function createBusiness(item: {
  name: string;
  ownerName: string;
  gstNumber?: string;
  phone: string;
  email: string;
  address?: string;
  businessType?: string;
  logoUrl?: string | null;
  currency?: string;
  language?: string;
  timezone?: string;
  invoicePrefix?: string;
  receiptSize?: string;
  taxPercentage?: number;
}) {
  try {
    const result = await db
      .insert(businesses)
      .values({
        name: item.name,
        ownerName: item.ownerName,
        gstNumber: item.gstNumber || "",
        phone: item.phone,
        email: item.email,
        address: item.address || "",
        businessType: item.businessType || "Retail",
        logoUrl: item.logoUrl || null,
        currency: item.currency || "USD",
        language: item.language || "English",
        timezone: item.timezone || "UTC",
        invoicePrefix: item.invoicePrefix || "INV",
        receiptSize: item.receiptSize || "3-inch",
        taxPercentage: item.taxPercentage !== undefined ? item.taxPercentage : 18,
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create business:", error);
    throw new Error("Failed to register business profile.", { cause: error });
  }
}

export async function getBusiness(id: number) {
  try {
    const result = await db.select().from(businesses).where(eq(businesses.id, id));
    return result[0] || null;
  } catch (error) {
    console.error("Failed to fetch business:", error);
    throw new Error("Failed to load business profile.", { cause: error });
  }
}

export async function updateBusiness(id: number, item: Partial<typeof businesses.$inferInsert>) {
  try {
    const result = await db
      .update(businesses)
      .set(item)
      .where(eq(businesses.id, id))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update business:", error);
    throw new Error("Failed to update business configuration.", { cause: error });
  }
}

// ==========================================
// USER & PROFILE MANAGEMENT (RBAC)
// ==========================================

export async function registerOrUpdateUser(
  uid: string,
  email: string,
  businessId?: number | null,
  role?: string,
  name?: string,
  phone?: string
) {
  try {
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        businessId: businessId || null,
        role: role || "cashier",
        name: name || "",
        phone: phone || "",
        status: "active",
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
          businessId: businessId !== undefined ? businessId : null,
          role: role || "cashier",
          name: name || "",
          phone: phone || "",
        },
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to register/update user profile:", error);
    throw new Error("User profile registration failed.", { cause: error });
  }
}

export async function getUserByUid(uid: string) {
  try {
    const result = await db.select().from(users).where(eq(users.uid, uid));
    return result[0] || null;
  } catch (error) {
    console.error("Failed to fetch user by UID:", error);
    throw new Error("Failed to load user profile.", { cause: error });
  }
}

export async function getUsersInBusiness(businessId: number) {
  try {
    return await db.select().from(users).where(eq(users.businessId, businessId));
  } catch (error) {
    console.error("Failed to fetch business users:", error);
    throw new Error("Failed to load employee user logs.", { cause: error });
  }
}

// ==========================================
// CATEGORY MANAGEMENT (NESTED)
// ==========================================

export async function getCategories(businessId: number) {
  try {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.businessId, businessId))
      .orderBy(categories.name);
  } catch (error) {
    console.error("Failed to fetch categories:", error);
    throw new Error("Failed to load product categories.", { cause: error });
  }
}

export async function createCategory(businessId: number, name: string, parentId?: number | null) {
  try {
    const result = await db
      .insert(categories)
      .values({
        businessId,
        name,
        parentId: parentId || null,
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create category:", error);
    throw new Error("Failed to create category.", { cause: error });
  }
}

export async function deleteCategory(id: number, businessId: number) {
  try {
    const result = await db
      .delete(categories)
      .where(and(eq(categories.id, id), eq(categories.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete category:", error);
    throw new Error("Failed to delete category.", { cause: error });
  }
}

// ==========================================
// SUPPLIER MANAGEMENT
// ==========================================

export async function getSuppliers(businessId: number) {
  try {
    return await db
      .select()
      .from(suppliers)
      .where(eq(suppliers.businessId, businessId))
      .orderBy(suppliers.name);
  } catch (error) {
    console.error("Failed to fetch suppliers:", error);
    throw new Error("Failed to load suppliers list.", { cause: error });
  }
}

export async function createSupplier(
  businessId: number,
  item: {
    name: string;
    contactPerson?: string;
    phone?: string;
    email?: string;
    address?: string;
    outstandingAmount?: number;
  }
) {
  try {
    const result = await db
      .insert(suppliers)
      .values({
        businessId,
        name: item.name,
        contactPerson: item.contactPerson || "",
        phone: item.phone || "",
        email: item.email || "",
        address: item.address || "",
        outstandingAmount: item.outstandingAmount || 0,
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create supplier:", error);
    throw new Error("Failed to create supplier record.", { cause: error });
  }
}

export async function updateSupplier(
  id: number,
  businessId: number,
  item: Partial<typeof suppliers.$inferInsert>
) {
  try {
    const result = await db
      .update(suppliers)
      .set(item)
      .where(and(eq(suppliers.id, id), eq(suppliers.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update supplier:", error);
    throw new Error("Failed to update supplier details.", { cause: error });
  }
}

export async function deleteSupplier(id: number, businessId: number) {
  try {
    const result = await db
      .delete(suppliers)
      .where(and(eq(suppliers.id, id), eq(suppliers.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete supplier:", error);
    throw new Error("Failed to remove supplier catalog.", { cause: error });
  }
}

// ==========================================
// PRODUCT CATALOG MANAGEMENT
// ==========================================

export async function getProducts(businessId: number) {
  try {
    return await db
      .select()
      .from(products)
      .where(eq(products.businessId, businessId))
      .orderBy(products.categoryName, products.id);
  } catch (error) {
    console.error("Failed to get products:", error);
    throw new Error("Failed to fetch product inventory catalog.", { cause: error });
  }
}

export async function createProduct(
  businessId: number,
  item: {
    name: string;
    categoryId?: number | null;
    categoryName?: string;
    brand?: string;
    barcode?: string;
    sku: string;
    mrp?: number;
    sellingPrice: number;
    purchasePrice?: number;
    gstPercentage?: number;
    discountPercentage?: number;
    stock: number;
    minStock?: number;
    expiryDate?: string | null;
    supplierId?: number | null;
    imageUrl?: string | null;
    status?: string;
    unit?: string;
  }
) {
  try {
    const result = await db
      .insert(products)
      .values({
        businessId,
        name: item.name,
        categoryId: item.categoryId || null,
        categoryName: item.categoryName || "General Store",
        brand: item.brand || "",
        barcode: item.barcode || "",
        sku: item.sku,
        mrp: item.mrp || item.sellingPrice,
        sellingPrice: item.sellingPrice,
        purchasePrice: item.purchasePrice || 0,
        gstPercentage: item.gstPercentage !== undefined ? item.gstPercentage : 18,
        discountPercentage: item.discountPercentage || 0,
        stock: item.stock,
        minStock: item.minStock !== undefined ? item.minStock : 5,
        expiryDate: item.expiryDate || null,
        supplierId: item.supplierId || null,
        imageUrl: item.imageUrl || null,
        status: item.status || "active",
        unit: item.unit || "pcs",
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create product:", error);
    throw new Error(`Failed to add product: ${error instanceof Error ? error.message : "Database error"}`, { cause: error });
  }
}

export async function updateProduct(
  id: number,
  businessId: number,
  item: Partial<typeof products.$inferInsert>
) {
  try {
    const result = await db
      .update(products)
      .set(item)
      .where(and(eq(products.id, id), eq(products.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update product:", error);
    throw new Error("Failed to modify product listing.", { cause: error });
  }
}

export async function updateProductStock(id: number, businessId: number, stock: number) {
  try {
    const result = await db
      .update(products)
      .set({ stock })
      .where(and(eq(products.id, id), eq(products.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update product stock:", error);
    throw new Error("Failed to update stock quantity.", { cause: error });
  }
}

export async function deleteProduct(id: number, businessId: number) {
  try {
    const result = await db
      .delete(products)
      .where(and(eq(products.id, id), eq(products.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete product:", error);
    throw new Error("Failed to delete inventory item.", { cause: error });
  }
}

// ==========================================
// CUSTOMER PROFILE MANAGEMENT
// ==========================================

export async function getCustomers(businessId: number) {
  try {
    return await db
      .select()
      .from(customers)
      .where(eq(customers.businessId, businessId))
      .orderBy(customers.name);
  } catch (error) {
    console.error("Failed to fetch customers:", error);
    throw new Error("Failed to load customer profiles.", { cause: error });
  }
}

export async function createCustomer(
  businessId: number,
  item: {
    name: string;
    phone?: string;
    email?: string;
    address?: string;
    loyaltyPoints?: number;
    outstandingBalance?: number;
  }
) {
  try {
    const result = await db
      .insert(customers)
      .values({
        businessId,
        name: item.name,
        phone: item.phone || "",
        email: item.email || "",
        address: item.address || "",
        loyaltyPoints: item.loyaltyPoints || 0,
        outstandingBalance: item.outstandingBalance || 0,
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create customer:", error);
    throw new Error("Failed to register customer profile.", { cause: error });
  }
}

export async function updateCustomer(
  id: number,
  businessId: number,
  item: Partial<typeof customers.$inferInsert>
) {
  try {
    const result = await db
      .update(customers)
      .set(item)
      .where(and(eq(customers.id, id), eq(customers.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update customer:", error);
    throw new Error("Failed to update customer loyalty points.", { cause: error });
  }
}

export async function deleteCustomer(id: number, businessId: number) {
  try {
    const result = await db
      .delete(customers)
      .where(and(eq(customers.id, id), eq(customers.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete customer:", error);
    throw new Error("Failed to remove customer ledger.", { cause: error });
  }
}

// ==========================================
// EXPENSE TRACKING MANAGEMENT
// ==========================================

export async function getExpenses(businessId: number) {
  try {
    return await db
      .select()
      .from(expenses)
      .where(eq(expenses.businessId, businessId))
      .orderBy(desc(expenses.date));
  } catch (error) {
    console.error("Failed to fetch expenses:", error);
    throw new Error("Failed to load company expense sheets.", { cause: error });
  }
}

export async function createExpense(
  businessId: number,
  item: {
    title: string;
    amount: number;
    category: string;
    date: string;
    notes?: string;
  }
) {
  try {
    const result = await db
      .insert(expenses)
      .values({
        businessId,
        title: item.title,
        amount: item.amount,
        category: item.category,
        date: item.date,
        notes: item.notes || "",
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create expense:", error);
    throw new Error("Failed to create expense voucher.", { cause: error });
  }
}

export async function deleteExpense(id: number, businessId: number) {
  try {
    const result = await db
      .delete(expenses)
      .where(and(eq(expenses.id, id), eq(expenses.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete expense:", error);
    throw new Error("Failed to purge expense records.", { cause: error });
  }
}

// ==========================================
// EMPLOYEE SALARY & ATTENDANCE MANAGEMENT
// ==========================================

export async function getEmployees(businessId: number) {
  try {
    return await db
      .select()
      .from(employees)
      .where(eq(employees.businessId, businessId))
      .orderBy(employees.name);
  } catch (error) {
    console.error("Failed to fetch employees:", error);
    throw new Error("Failed to load active employee registers.", { cause: error });
  }
}

export async function createEmployee(
  businessId: number,
  item: {
    name: string;
    role?: string;
    salary?: number;
    attendanceJson?: string;
    phone?: string;
    email?: string;
  }
) {
  try {
    const result = await db
      .insert(employees)
      .values({
        businessId,
        name: item.name,
        role: item.role || "Cashier",
        salary: item.salary || 0,
        attendanceJson: item.attendanceJson || "{}",
        phone: item.phone || "",
        email: item.email || "",
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to create employee profile:", error);
    throw new Error("Failed to create employee record.", { cause: error });
  }
}

export async function updateEmployee(
  id: number,
  businessId: number,
  item: Partial<typeof employees.$inferInsert>
) {
  try {
    const result = await db
      .update(employees)
      .set(item)
      .where(and(eq(employees.id, id), eq(employees.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to update employee logs:", error);
    throw new Error("Failed to modify employee profiles.", { cause: error });
  }
}

export async function deleteEmployee(id: number, businessId: number) {
  try {
    const result = await db
      .delete(employees)
      .where(and(eq(employees.id, id), eq(employees.businessId, businessId)))
      .returning();
    return result[0];
  } catch (error) {
    console.error("Failed to delete employee:", error);
    throw new Error("Failed to remove employee file.", { cause: error });
  }
}

// ==========================================
// REAL POS BILLING TRANSACTION ENGINE
// ==========================================

export async function createTransaction(checkout: {
  businessId: number;
  invoiceNumber: string;
  customerId?: number | null;
  customerName: string;
  subtotal: number;
  discount: number;
  taxAmount: number;
  total: number;
  paymentMethod: string;
  splitDetails?: string | null;
  paymentStatus: string;
  operatorId?: string | null;
  items: {
    productId: number;
    productName: string;
    quantity: number;
    price: number;
    taxAmount?: number;
    discountAmount?: number;
  }[];
}) {
  try {
    // 1. Insert POS invoice
    const [tx] = await db
      .insert(transactions)
      .values({
        businessId: checkout.businessId,
        invoiceNumber: checkout.invoiceNumber,
        customerId: checkout.customerId || null,
        customerName: checkout.customerName,
        subtotal: checkout.subtotal,
        discount: checkout.discount,
        taxAmount: checkout.taxAmount,
        total: checkout.total,
        paymentMethod: checkout.paymentMethod,
        splitDetails: checkout.splitDetails || null,
        paymentStatus: checkout.paymentStatus,
        operatorId: checkout.operatorId || "Cashier",
      })
      .returning();

    if (!tx) {
      throw new Error("Failed to instantiate transaction header.");
    }

    // 2. Insert invoice line-items & log stock changes
    for (const item of checkout.items) {
      await db.insert(transactionItems).values({
        transactionId: tx.id,
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        price: item.price,
        taxAmount: item.taxAmount || 0,
        discountAmount: item.discountAmount || 0,
      });

      // Deduct product stock count
      const [prod] = await db
        .select()
        .from(products)
        .where(and(eq(products.id, item.productId), eq(products.businessId, checkout.businessId)));
      
      if (prod) {
        const remainingStock = Math.max(0, prod.stock - item.quantity);
        await db
          .update(products)
          .set({ stock: remainingStock })
          .where(eq(products.id, item.productId));

        // Create transaction logs
        await db.insert(inventoryLogs).values({
          businessId: checkout.businessId,
          productId: item.productId,
          productName: item.productName,
          type: "Stock Out",
          quantity: item.quantity,
          reason: `Sale Invoice #${checkout.invoiceNumber}`,
        });
      }
    }

    // Adjust customer loyalty points (+1 point for every $10 spent)
    if (checkout.customerId) {
      const [cust] = await db
        .select()
        .from(customers)
        .where(and(eq(customers.id, checkout.customerId), eq(customers.businessId, checkout.businessId)));
      if (cust) {
        const pointsAwarded = Math.floor(checkout.total / 10);
        const outstanding = checkout.paymentStatus === "Pending" ? checkout.total : 0;
        await db
          .update(customers)
          .set({
            loyaltyPoints: (cust.loyaltyPoints || 0) + pointsAwarded,
            outstandingBalance: Number(cust.outstandingBalance || 0) + outstanding,
          })
          .where(eq(customers.id, checkout.customerId));
      }
    }

    return tx;
  } catch (error) {
    console.error("Billing checkout sequence failed:", error);
    throw new Error("Checkout failed to process transactions in database.", { cause: error });
  }
}

export async function getTransactions(businessId: number) {
  try {
    const list = await db
      .select()
      .from(transactions)
      .where(eq(transactions.businessId, businessId))
      .orderBy(desc(transactions.createdAt));

    const result = [];
    for (const tx of list) {
      const items = await db
        .select()
        .from(transactionItems)
        .where(eq(transactionItems.transactionId, tx.id));
      result.push({
        ...tx,
        items,
      });
    }
    return result;
  } catch (error) {
    console.error("Failed to load transactions history:", error);
    throw new Error("Failed to load invoice lists.", { cause: error });
  }
}

// ==========================================
// INVENTORY HISTORY & ADJUSTMENTS
// ==========================================

export async function getInventoryLogs(businessId: number) {
  try {
    return await db
      .select()
      .from(inventoryLogs)
      .where(eq(inventoryLogs.businessId, businessId))
      .orderBy(desc(inventoryLogs.createdAt));
  } catch (error) {
    console.error("Failed to load inventory logs:", error);
    throw new Error("Failed to retrieve stock adjustment history.", { cause: error });
  }
}

export async function createInventoryLog(
  businessId: number,
  item: {
    productId: number;
    productName: string;
    type: "Stock In" | "Stock Out" | "Adjustment" | "Transfer";
    quantity: number;
    reason?: string;
  }
) {
  try {
    // 1. Insert inventory log
    const [log] = await db
      .insert(inventoryLogs)
      .values({
        businessId,
        productId: item.productId,
        productName: item.productName,
        type: item.type,
        quantity: item.quantity,
        reason: item.reason || "",
      })
      .returning();

    // 2. Adjust physical product stock count accordingly
    const [prod] = await db
      .select()
      .from(products)
      .where(and(eq(products.id, item.productId), eq(products.businessId, businessId)));
    if (prod) {
      let delta = item.quantity;
      if (item.type === "Stock Out" || item.type === "Transfer") {
        delta = -Math.abs(item.quantity);
      } else {
        delta = Math.abs(item.quantity);
      }
      const updatedStock = Math.max(0, prod.stock + delta);
      await db
        .update(products)
        .set({ stock: updatedStock })
        .where(eq(products.id, item.productId));
    }
    return log;
  } catch (error) {
    console.error("Failed to record inventory adjustment:", error);
    throw new Error("Adjustment transaction aborted.", { cause: error });
  }
}
