import { relations } from "drizzle-orm";
import { pgTable, serial, text, integer, doublePrecision, timestamp } from "drizzle-orm/pg-core";

// 1. Businesses (Tenants) Table
export const businesses = pgTable("businesses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ownerName: text("owner_name").notNull(),
  gstNumber: text("gst_number").default(""),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  address: text("address").default(""),
  businessType: text("business_type").default("Retail"), // Retail, Grocery, Supermarket, Pharmacy, Wholesale, Restaurant
  logoUrl: text("logo_url"),
  currency: text("currency").default("USD"),
  language: text("language").default("English"),
  timezone: text("timezone").default("UTC"),
  invoicePrefix: text("invoice_prefix").default("INV"),
  receiptSize: text("receipt_size").default("3-inch"), // 2-inch, 3-inch, A4
  taxPercentage: doublePrecision("tax_percentage").default(18), // Standard GST / VAT
  createdAt: timestamp("created_at").defaultNow(),
});

// 2. Users Table with Role-Based Access Control (RBAC)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(), // Firebase Auth UID
  email: text("email").notNull(),
  name: text("name").default(""),
  phone: text("phone").default(""),
  businessId: integer("business_id").references(() => businesses.id, { onDelete: "cascade" }), // Nullable for system-wide Super Admins
  role: text("role").default("cashier"), // super_admin, owner, manager, cashier
  status: text("status").default("active"), // active, inactive
  createdAt: timestamp("created_at").defaultNow(),
});

// 3. Categories Table (Supports Nested/Subcategories)
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  parentId: integer("parent_id"), // Self-reference for nested categories
  createdAt: timestamp("created_at").defaultNow(),
});

// 4. Suppliers Table
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  contactPerson: text("contact_person").default(""),
  phone: text("phone").default(""),
  email: text("email").default(""),
  address: text("address").default(""),
  outstandingAmount: doublePrecision("outstanding_amount").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// 5. Products Table (Detailed Item Catalog)
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
  categoryName: text("category_name").default("General Store"), // Denormalized fallback category
  brand: text("brand").default(""),
  barcode: text("barcode").default(""),
  sku: text("sku").notNull(), // Stock keeping unit / scanned barcode
  mrp: doublePrecision("mrp").default(0), // Maximum Retail Price
  sellingPrice: doublePrecision("selling_price").notNull(),
  purchasePrice: doublePrecision("purchase_price").default(0),
  gstPercentage: doublePrecision("gst_percentage").default(18),
  discountPercentage: doublePrecision("discount_percentage").default(0),
  stock: integer("stock").notNull().default(0),
  minStock: integer("min_stock").default(5), // Low stock alert trigger
  expiryDate: text("expiry_date"), // Expiry Alerts
  supplierId: integer("supplier_id").references(() => suppliers.id, { onDelete: "set null" }),
  imageUrl: text("image_url"),
  status: text("status").default("active"), // active, inactive
  unit: text("unit").default("pcs"), // pcs, kg, pack, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

// 6. Customers Table
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  phone: text("phone").default(""),
  email: text("email").default(""),
  address: text("address").default(""),
  loyaltyPoints: integer("loyalty_points").default(0),
  outstandingBalance: doublePrecision("outstanding_balance").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// 7. Invoices (Checkout Transactions)
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  invoiceNumber: text("invoice_number").notNull(), // Generated with prefix (e.g. ABC-INV-1001)
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
  customerName: text("customer_name").notNull().default("Guest"),
  subtotal: doublePrecision("subtotal").notNull(),
  discount: doublePrecision("discount").notNull().default(0),
  taxAmount: doublePrecision("tax_amount").notNull().default(0),
  total: doublePrecision("total").notNull(),
  paymentMethod: text("payment_method").notNull().default("Card"), // UPI, Card, Cash, Wallet, Split
  splitDetails: text("split_details"), // JSON or details of split payment
  paymentStatus: text("payment_status").notNull().default("Paid"), // Paid, Pending, Refunded
  operatorId: text("operator_id"), // Operator or Cashier name/ID for auditing
  createdAt: timestamp("created_at").defaultNow(),
});

// 8. Transaction Items (Line details of invoices)
export const transactionItems = pgTable("transaction_items", {
  id: serial("id").primaryKey(),
  transactionId: integer("transaction_id")
    .references(() => transactions.id, { onDelete: "cascade" })
    .notNull(),
  productId: integer("product_id")
    .references(() => products.id, { onDelete: "set null" }),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  price: doublePrecision("price").notNull(), // Capture price at purchase
  taxAmount: doublePrecision("tax_amount").default(0),
  discountAmount: doublePrecision("discount_amount").default(0),
});

// 9. Expenses Table
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(), // Rent, Utilities, Salary, Inventory, Marketing, Other
  date: text("date").notNull(), // YYYY-MM-DD
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// 10. Employees Table
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  role: text("role").default("Cashier"), // Manager, Cashier, Stockist
  salary: doublePrecision("salary").default(0),
  attendanceJson: text("attendance_json").default("{}"), // Monthly attendance log
  phone: text("phone").default(""),
  email: text("email").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

// 11. Inventory Logs Table
export const inventoryLogs = pgTable("inventory_logs", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id")
    .references(() => businesses.id, { onDelete: "cascade" })
    .notNull(),
  productId: integer("product_id").references(() => products.id, { onDelete: "cascade" }),
  productName: text("product_name").notNull(),
  type: text("type").notNull(), // "Stock In", "Stock Out", "Adjustment", "Transfer"
  quantity: integer("quantity").notNull(),
  reason: text("reason").default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations Definitions
export const businessesRelations = relations(businesses, ({ many }) => ({
  users: many(users),
  categories: many(categories),
  products: many(products),
  customers: many(customers),
  suppliers: many(suppliers),
  transactions: many(transactions),
  expenses: many(expenses),
  employees: many(employees),
  inventoryLogs: many(inventoryLogs),
}));

export const usersRelations = relations(users, ({ one }) => ({
  business: one(businesses, {
    fields: [users.businessId],
    references: [businesses.id],
  }),
}));

export const categoriesRelations = relations(categories, ({ one, many }) => ({
  business: one(businesses, {
    fields: [categories.businessId],
    references: [businesses.id],
  }),
  parent: one(categories, {
    fields: [categories.parentId],
    references: [categories.id],
    relationName: "categoryNesting",
  }),
  subcategories: many(categories, {
    relationName: "categoryNesting",
  }),
  products: many(products),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  business: one(businesses, {
    fields: [products.businessId],
    references: [businesses.id],
  }),
  category: one(categories, {
    fields: [products.categoryId],
    references: [categories.id],
  }),
  supplier: one(suppliers, {
    fields: [products.supplierId],
    references: [suppliers.id],
  }),
  items: many(transactionItems),
  inventoryLogs: many(inventoryLogs),
}));

export const customersRelations = relations(customers, ({ one, many }) => ({
  business: one(businesses, {
    fields: [customers.businessId],
    references: [businesses.id],
  }),
  transactions: many(transactions),
}));

export const suppliersRelations = relations(suppliers, ({ one, many }) => ({
  business: one(businesses, {
    fields: [suppliers.businessId],
    references: [businesses.id],
  }),
  products: many(products),
}));

export const transactionsRelations = relations(transactions, ({ one, many }) => ({
  business: one(businesses, {
    fields: [transactions.businessId],
    references: [businesses.id],
  }),
  customer: one(customers, {
    fields: [transactions.customerId],
    references: [customers.id],
  }),
  items: many(transactionItems),
}));

export const transactionItemsRelations = relations(transactionItems, ({ one }) => ({
  transaction: one(transactions, {
    fields: [transactionItems.transactionId],
    references: [transactions.id],
  }),
  product: one(products, {
    fields: [transactionItems.productId],
    references: [products.id],
  }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  business: one(businesses, {
    fields: [expenses.businessId],
    references: [businesses.id],
  }),
}));

export const employeesRelations = relations(employees, ({ one }) => ({
  business: one(businesses, {
    fields: [employees.businessId],
    references: [businesses.id],
  }),
}));

export const inventoryLogsRelations = relations(inventoryLogs, ({ one }) => ({
  business: one(businesses, {
    fields: [inventoryLogs.businessId],
    references: [businesses.id],
  }),
  product: one(products, {
    fields: [inventoryLogs.productId],
    references: [products.id],
  }),
}));
