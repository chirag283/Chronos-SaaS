import React, { useState, useEffect } from "react";
import { Product } from "../types";
import { Plus, Trash2, Edit3, Save, RefreshCw, Layers, Sparkles, PlusCircle } from "lucide-react";

interface InventoryManagerProps {
  products?: Product[];
  authToken?: string | null;
  onRefreshProducts?: () => Promise<void>;
  onProductCreated?: () => void;
  activeBusinessId?: number;
}

export default function InventoryManager({ 
  products, 
  authToken, 
  onRefreshProducts, 
  onProductCreated,
  activeBusinessId 
}: InventoryManagerProps) {
  const [items, setItems] = useState<Product[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editStock, setEditStock] = useState<number>(0);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  
  // New Product Form state
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [newProductName, setNewProductName] = useState<string>("");
  const [newProductCategory, setNewProductCategory] = useState<string>("General Store");
  const [newProductPrice, setNewProductPrice] = useState<string>("");
  const [newProductStock, setNewProductStock] = useState<string>("50");
  const [newProductUnit, setNewProductUnit] = useState<string>("pcs");
  const [newProductLabel, setNewProductLabel] = useState<string>("Regular");
  const [newProductSku, setNewProductSku] = useState<string>("");
  const [newProductImage, setNewProductImage] = useState<string>("");
  const [generatingImage, setGeneratingImage] = useState<boolean>(false);
  const [imageGenerationError, setImageGenerationError] = useState<string | null>(null);

  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Fetch products scoped to current business tenant
  const fetchScopedProducts = async () => {
    if (!activeBusinessId) return;
    setLoading(true);
    try {
      const res = await fetch("/api/products", {
        headers: { "x-business-id": activeBusinessId.toString() }
      });
      if (res.ok) {
        const prodData = await res.json();
        const mapped: Product[] = prodData.map((p: any) => ({
          id: p.id,
          name: p.name,
          category: p.categoryName || "General Store",
          price: Number(p.sellingPrice || 0),
          stock: Number(p.stock || 0),
          unit: p.unit || "pcs",
          sku: p.sku || p.barcode || "",
          imageUrl: p.imageUrl,
          label: p.brand
        }));
        setItems(mapped);
      }
    } catch (e) {
      console.warn("REST sync failed in manager modal", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeBusinessId) {
      fetchScopedProducts();
    } else if (products) {
      setItems(products);
    }
  }, [products, activeBusinessId]);

  const handleGenerateAIImage = async () => {
    if (!newProductName.trim()) {
      setImageGenerationError("Please enter a product name first to generate an image.");
      return;
    }

    setGeneratingImage(true);
    setImageGenerationError(null);

    try {
      const res = await fetch("/api/products/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-business-id": activeBusinessId ? activeBusinessId.toString() : "1"
        },
        body: JSON.stringify({
          name: newProductName,
          category: newProductCategory,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to generate AI image.");
      }

      setNewProductImage(data.imageUrl);
    } catch (err: any) {
      console.error(err);
      setImageGenerationError(err.message || "Failed to generate AI image.");
      // Fallback picsum seed
      setNewProductImage(`https://picsum.photos/seed/${encodeURIComponent(newProductName)}/300/300`);
    } finally {
      setGeneratingImage(false);
    }
  };

  // Handle stock update
  const handleUpdateStock = async (id: number) => {
    setIsSaving(true);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (activeBusinessId) {
        headers["x-business-id"] = activeBusinessId.toString();
      }

      const res = await fetch(`/api/products/${id}/stock`, {
        method: "PUT",
        headers,
        body: JSON.stringify({ stock: editStock }),
      });

      if (!res.ok) {
        throw new Error("Failed to update stock in database.");
      }

      if (onRefreshProducts) await onRefreshProducts();
      if (onProductCreated) onProductCreated();
      if (activeBusinessId) fetchScopedProducts();
      setEditingId(null);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setIsSaving(false);
    }
  };

  // Handle product deletion
  const handleDeleteProduct = async (id: number) => {
    if (!confirm("Are you sure you want to permanently delete this product from the database?")) {
      return;
    }

    try {
      const headers: Record<string, string> = {};
      if (activeBusinessId) {
        headers["x-business-id"] = activeBusinessId.toString();
      }

      const res = await fetch(`/api/products/${id}`, {
        method: "DELETE",
        headers,
      });

      if (!res.ok) {
        throw new Error("Failed to delete product.");
      }

      if (onRefreshProducts) await onRefreshProducts();
      if (onProductCreated) onProductCreated();
      if (activeBusinessId) fetchScopedProducts();
    } catch (e: any) {
      alert(e.message);
    }
  };

  // Generate a random SKU barcode value
  const handleAutoGenerateSku = () => {
    const categoriesPrefix: Record<string, string> = {
      "General Store": "GEN",
      Produce: "PRO",
      Beverages: "BEV",
      Fashion: "FAS",
      Medicine: "MED",
      Devices: "DEV",
      Appetizers: "APP",
    };
    const prefix = categoriesPrefix[newProductCategory] || "PRD";
    const rand = Math.floor(100000 + Math.random() * 900000);
    setNewProductSku(`${prefix}-${rand}`);
  };

  // Handle creating new item
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    if (!newProductName || !newProductPrice || !newProductStock || !newProductSku) {
      setFormError("Please fill out all required fields: Name, Price, Stock, and SKU.");
      return;
    }

    setLoading(true);
    
    const defaultImages: Record<string, string> = {
      "General Store": "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=150&q=80",
      Produce: "https://images.unsplash.com/photo-1540340061722-9293d5163008?w=150&q=80",
      Beverages: "https://images.unsplash.com/photo-1527960650-0972242549d8?w=150&q=80",
      Fashion: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=150&q=80",
      Medicine: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=150&q=80",
    };

    const payload = {
      name: newProductName,
      category: newProductCategory,
      price: parseFloat(newProductPrice),
      stock: parseInt(newProductStock),
      unit: newProductUnit,
      label: newProductLabel,
      sku: newProductSku,
      imageUrl: newProductImage || defaultImages[newProductCategory] || "https://picsum.photos/seed/default/200/200",
    };

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (activeBusinessId) {
        headers["x-business-id"] = activeBusinessId.toString();
      }

      const res = await fetch("/api/products", {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to create new inventory item.");
      }

      setFormSuccess(`Successfully added "${newProductName}" to stock list!`);
      
      // Reset form fields
      setNewProductName("");
      setNewProductPrice("");
      setNewProductStock("50");
      setNewProductSku("");
      setNewProductImage("");
      
      if (onRefreshProducts) await onRefreshProducts();
      if (onProductCreated) onProductCreated();
      if (activeBusinessId) fetchScopedProducts();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6" id="inventory-manager-container">
      
      {/* Control Actions Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-display font-semibold text-base text-slate-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-600" /> Stock Control Panel
          </h3>
          <p className="text-xs text-slate-400 font-mono mt-0.5">Total products on shelf: {items.length}</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1.5 self-start px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition"
        >
          <Plus className="w-3.5 h-3.5" />
          {showAddForm ? "Close Form" : "Add Catalog Line"}
        </button>
      </div>

      {/* Add Product Form */}
      {showAddForm && (
        <form onSubmit={handleAddProduct} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col gap-5">
          <div className="border-b border-slate-200 pb-3">
            <h4 className="font-display font-semibold text-xs text-slate-800 flex items-center gap-1.5">
              <PlusCircle className="w-4 h-4 text-indigo-600" /> Register Product Form
            </h4>
          </div>

          {formError && (
            <div className="bg-rose-50 text-rose-600 border border-rose-250 text-[11px] rounded-xl p-2.5 font-mono">
              {formError}
            </div>
          )}

          {formSuccess && (
            <div className="bg-emerald-50 text-emerald-600 border border-emerald-250 text-[11px] rounded-xl p-2.5 font-sans font-semibold">
              {formSuccess}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Name */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Product Name *</label>
              <input
                type="text"
                placeholder="e.g. Cotton Blue Jeans"
                value={newProductName}
                onChange={(e) => setNewProductName(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Category */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Category *</label>
              <select
                value={newProductCategory}
                onChange={(e) => setNewProductCategory(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none text-slate-600"
              >
                <option value="General Store">General Store</option>
                <option value="Produce">Produce</option>
                <option value="Beverages">Beverages</option>
                <option value="Wellness">Wellness</option>
                <option value="Medicine">Medicine</option>
                <option value="Devices">Devices</option>
                <option value="Appetizers">Appetizers</option>
                <option value="Main Course">Main Course</option>
                <option value="Fashion">Fashion</option>
                <option value="Footwear">Footwear</option>
              </select>
            </div>

            {/* Price */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Price *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                placeholder="29.99"
                value={newProductPrice}
                onChange={(e) => setNewProductPrice(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Stock */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Initial Stock *</label>
              <input
                type="number"
                min="0"
                placeholder="100"
                value={newProductStock}
                onChange={(e) => setNewProductStock(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none"
              />
            </div>

            {/* Unit */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Unit Type</label>
              <input
                type="text"
                placeholder="e.g. pcs, kg, box, pair"
                value={newProductUnit}
                onChange={(e) => setNewProductUnit(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none"
              />
            </div>

            {/* Label */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Badge Label</label>
              <input
                type="text"
                placeholder="e.g. Hot, New, Regular, Premium"
                value={newProductLabel}
                onChange={(e) => setNewProductLabel(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none"
              />
            </div>

            {/* SKU / Barcode */}
            <div className="flex flex-col gap-1 md:col-span-2">
              <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold flex items-center justify-between">
                <span>SKU Barcode Value *</span>
                <button
                  type="button"
                  onClick={handleAutoGenerateSku}
                  className="text-indigo-600 hover:underline hover:text-indigo-550 normal-case font-sans text-[10px] font-bold"
                >
                  Auto-Generate Barcode
                </button>
              </label>
              <input
                type="text"
                placeholder="e.g. SKU-FAS-CHINOS (Unique)"
                value={newProductSku}
                onChange={(e) => setNewProductSku(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Image URL & AI Generator */}
            <div className="flex flex-col gap-1.5 md:col-span-3 border-t border-slate-200/60 pt-3 mt-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <label className="text-[10px] text-slate-500 font-mono uppercase tracking-wider font-semibold">Product Image URL</label>
                  <p className="text-[10px] text-slate-400 mt-0.5">Let Gemini AI generate a descriptive product image for you!</p>
                </div>
                
                <button
                  type="button"
                  onClick={handleGenerateAIImage}
                  disabled={generatingImage || !newProductName.trim()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 disabled:opacity-50 transition cursor-pointer"
                >
                  <Sparkles className={`w-3.5 h-3.5 text-indigo-500 ${generatingImage ? "animate-spin" : ""}`} />
                  {generatingImage ? "Generating Image..." : "Generate image with Gemini"}
                </button>
              </div>

              {imageGenerationError && (
                <p className="text-[10px] text-rose-500 font-mono mt-0.5">{imageGenerationError}</p>
              )}

              <div className="flex flex-col sm:flex-row gap-3 mt-1">
                <input
                  type="text"
                  placeholder="Paste URL or let the generator fill this in"
                  value={newProductImage}
                  onChange={(e) => setNewProductImage(e.target.value)}
                  className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none flex-1"
                />

                {newProductImage && (
                  <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200 self-start shrink-0">
                    <img
                      src={newProductImage}
                      alt="Preview"
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded object-cover border border-slate-300"
                    />
                    <div className="text-[9px] text-slate-500 font-mono pr-1.5 max-w-[120px] truncate">
                      Image Ready
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="self-end px-4 py-2 bg-slate-800 hover:bg-slate-900 disabled:bg-gray-300 text-white rounded-xl text-xs font-semibold transition"
          >
            {loading ? "Adding..." : "Add to SQL Database"}
          </button>
        </form>
      )}

      {/* Stock Inventory Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-mono uppercase text-[9px] font-bold tracking-wider">
                <th className="px-5 py-3.5">Product Name / Sku</th>
                <th className="px-5 py-3.5">Category</th>
                <th className="px-5 py-3.5">Price</th>
                <th className="px-5 py-3.5">Current Stock</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans text-xs">
              {items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={item.imageUrl || `https://picsum.photos/seed/${item.name}/200/200`}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-8 h-8 rounded object-cover bg-slate-100 border border-slate-200 flex-shrink-0"
                      />
                      <div>
                        <div className="font-semibold text-slate-800">{item.name}</div>
                        <div className="font-mono text-[9px] text-slate-400 mt-0.5">{item.sku}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 border border-slate-200 text-slate-600 font-mono">
                      {item.category}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 font-semibold text-slate-800">${item.price.toFixed(2)}</td>
                  <td className="px-5 py-3.5">
                    {editingId === item.id ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          value={editStock}
                          onChange={(e) => setEditStock(parseInt(e.target.value) || 0)}
                          className="w-16 border border-slate-300 rounded px-1.5 py-0.5 font-mono text-center focus:outline-none"
                        />
                        <span className="text-[10px] text-slate-400 font-mono">{item.unit}</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <span className={`font-mono font-bold ${item.stock <= 5 ? "text-rose-600" : item.stock <= 15 ? "text-amber-500" : "text-slate-800"}`}>
                          {item.stock}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{item.unit}</span>
                        {item.stock <= 5 && (
                          <span className="bg-rose-50 border border-rose-100 text-rose-500 font-sans text-[8px] px-1 py-0.2 rounded font-semibold uppercase animate-pulse">
                            Low
                          </span>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-5 py-3.5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {editingId === item.id ? (
                        <>
                          <button
                            onClick={() => handleUpdateStock(item.id)}
                            disabled={isSaving}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded border border-emerald-200 transition"
                            title="Save stock value"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded transition"
                            title="Cancel editing"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setEditingId(item.id);
                              setEditStock(item.stock);
                            }}
                            className="p-1 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded transition"
                            title="Edit stock level"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(item.id)}
                            className="p-1 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              
              {items.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-slate-400 font-mono text-xs">
                    No products found in database inventory.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

function PlusCircleIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
  );
}
