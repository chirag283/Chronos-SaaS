import React, { useState, useEffect } from "react";
import { Product, CartItem, Transaction } from "../types";
import {
  ShoppingBag,
  Calculator,
  Layers,
  History,
  QrCode,
  Plus,
  Minus,
  Trash2,
  Percent,
  CreditCard,
  CheckCircle,
  User,
  Check,
  X,
  PlusCircle,
  DollarSign,
  Volume2,
  VolumeX,
  ShieldCheck,
  Lock,
  Bell,
  AlertTriangle,
  Sliders,
  Printer,
  Radar,
  Users,
  Briefcase,
  TrendingUp,
  Tag,
  Sparkles,
  Search,
  Package,
  HardDrive,
  Heart,
  Palette,
  Truck,
  RotateCcw,
  CheckCircle2,
  Calendar
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ScientificCalculator from "./ScientificCalculator.tsx";
import SaaSOnboarding, { TenantBusiness } from "./SaaSOnboarding.tsx";
import SaasDashboard from "./SaaSDashboard.tsx";
import InventoryManager from "./InventoryManager.tsx";
import SaaSInvoiceReceipt from "./SaaSInvoiceReceipt.tsx";

const AVAILABLE_THEMES = [
  { id: "slate", label: "Midnight Slate", primary: "bg-slate-800", text: "text-slate-800", border: "border-slate-200", btn: "bg-slate-700 hover:bg-slate-800" },
  { id: "indigo", label: "Royal Indigo", primary: "bg-indigo-600", text: "text-indigo-600", border: "border-indigo-200", btn: "bg-indigo-600 hover:bg-indigo-700" },
  { id: "emerald", label: "Forest Emerald", primary: "bg-emerald-600", text: "text-emerald-600", border: "border-emerald-200", btn: "bg-emerald-600 hover:bg-emerald-700" },
  { id: "rose", label: "Warm Rose", primary: "bg-rose-600", text: "text-rose-600", border: "border-rose-200", btn: "bg-rose-600 hover:bg-rose-700" }
];

// Prepopulated Demo Businesses in case Database is fresh or unconfigured
const DEMO_TENANTS: TenantBusiness[] = [
  { id: 1, name: "Prime Mart Grocery", ownerName: "John Doe", gstNumber: "27AAAAA1111A1Z1", phone: "+1 (555) 012-3456", email: "contact@primemart.com", address: "742 Evergreen Terrace", businessType: "Grocery", currency: "USD", language: "English", timezone: "America/New_York", invoicePrefix: "PRIME-INV", receiptSize: "3-inch", taxPercentage: 18 },
  { id: 2, name: "Vogue Attire Boutique", ownerName: "Emma Watson", gstNumber: "VAT-8239401", phone: "+33 1 42 27 78 00", email: "billing@vogue.fr", address: "12 Avenue des Champs-Élysées", businessType: "Fashion", currency: "EUR", language: "French", timezone: "Europe/Paris", invoicePrefix: "VOGUE-INV", receiptSize: "A4", taxPercentage: 15 },
  { id: 3, name: "MedLife Rx Pharmacy", ownerName: "Dr. Robert Chen", gstNumber: "GST-MED923", phone: "+91 98765 43210", email: "ops@medliferx.in", address: "G-42, Sector 18, Noida", businessType: "Pharmacy", currency: "INR", language: "Hindi", timezone: "Asia/Kolkata", invoicePrefix: "MED-INV", receiptSize: "2-inch", taxPercentage: 12 },
  { id: 4, name: "BiteByte Bistro", ownerName: "Chef Gordon", gstNumber: "UK-VAT-9034", phone: "+44 20 7946 0958", email: "eat@bitebyte.co.uk", address: "221B Baker St, London", businessType: "Restaurant", currency: "GBP", language: "English", timezone: "Europe/London", invoicePrefix: "BITE-INV", receiptSize: "3-inch", taxPercentage: 20 }
];

export default function ECommerceFrame() {
  const [activeTab, setActiveTab] = useState<"store" | "dashboard" | "inventory" | "categories" | "customers" | "suppliers" | "expenses" | "employees" | "settings" | "calc">("store");
  
  // Theme & Sound Effects Preferences
  const [activeTheme, setActiveTheme] = useState<string>("indigo");
  const [enableVoice, setEnableVoice] = useState<boolean>(true);

  // Multi-Tenant Business Profiles & Active User Roles (RBAC)
  const [businessesList, setBusinessesList] = useState<TenantBusiness[]>(() => {
    try {
      const saved = localStorage.getItem("chronos_tenant_businesses");
      return saved ? JSON.parse(saved) : DEMO_TENANTS;
    } catch {
      return DEMO_TENANTS;
    }
  });

  const [activeBusinessId, setActiveBusinessId] = useState<number>(() => {
    try {
      const saved = localStorage.getItem("chronos_active_business_id");
      return saved ? Number(saved) : 1;
    } catch {
      return 1;
    }
  });

  const activeBusiness = businessesList.find((b) => b.id === activeBusinessId) || businessesList[0];

  const [activeRole, setActiveRole] = useState<"super_admin" | "owner" | "manager" | "cashier">("owner");

  // Global lists - synced either through APIs or localStorage fallback
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [inventoryLogs, setInventoryLogs] = useState<any[]>([]);

  // Local Storage synchronizers
  useEffect(() => {
    localStorage.setItem("chronos_tenant_businesses", JSON.stringify(businessesList));
  }, [businessesList]);

  useEffect(() => {
    localStorage.setItem("chronos_active_business_id", activeBusinessId.toString());
  }, [activeBusinessId]);

  // Billing Cart & Operator states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerSearchQuery, setCustomerSearchQuery] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [selectedCustomerName, setSelectedCustomerName] = useState("Guest Customer");
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [couponCodeInput, setCouponCodeInput] = useState("");
  const [activeCouponDiscount, setActiveCouponDiscount] = useState<number>(0); // Absolute amount deduction
  const [paymentMethod, setPaymentMethod] = useState<"Cash" | "UPI" | "Card" | "Wallet" | "Split" | "EMI">("Card");
  const [splitCashAmount, setSplitCashAmount] = useState<string>("");
  const [splitCardAmount, setSplitCardAmount] = useState<string>("");

  // Connectivity & Sync states
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Loyalty Reward points state
  const [redeemLoyalty, setRedeemLoyalty] = useState<boolean>(false);

  // EMI state
  const [emiTerm, setEmiTerm] = useState<number>(3); // 3, 6, or 12 months
  const [downPaymentInput, setDownPaymentInput] = useState<string>("");

  // AI Chatbot Co-Pilot states
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<any[]>([
    {
      role: "model",
      text: "👋 Hi! I am your Chronos AI Co-Pilot. I have direct access to your store's live PostgreSQL database.\n\nAsk me questions like:\n- *'Today's sales?'*\n- *'Which items are low in stock?'*\n- *'What is our best-selling product?'*"
    }
  ]);
  const [chatInput, setChatInput] = useState<string>("");
  const [chatLoading, setChatLoading] = useState<boolean>(false);

  // Barcode / Scanner states
  const [showScanner, setShowScanner] = useState<boolean>(false);
  const [scanSkuInput, setScanSkuInput] = useState<string>("");
  const [scanStatus, setScanStatus] = useState<string | null>(null);

  // Printer Spool lists
  const [printers, setPrinters] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("chronos_printers");
      return saved ? JSON.parse(saved) : [
        { id: "p1", name: "Main Thermal Spool", ip: "127.0.0.1", port: 9100, isDefault: true, status: "ONLINE" }
      ];
    } catch {
      return [{ id: "p1", name: "Main Thermal Spool", ip: "127.0.0.1", port: 9100, isDefault: true, status: "ONLINE" }];
    }
  });

  const [isScanningPrinters, setIsScanningPrinters] = useState(false);
  const [newPrinterName, setNewPrinterName] = useState("");
  const [newPrinterIp, setNewPrinterIp] = useState("");
  const [newPrinterPort, setNewPrinterPort] = useState(9100);

  // Receipts / Checkout states
  const [showReceipt, setShowReceipt] = useState<boolean>(false);
  const [lastTransaction, setLastTransaction] = useState<Transaction | null>(null);
  const [checkoutLoading, setCheckoutLoading] = useState<boolean>(false);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(5);

  // Form input states
  const [productSearch, setProductSearch] = useState("");
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState("All");

  // Notifications
  const [toasts, setToasts] = useState<any[]>([]);

  const addToast = (title: string, message: string, type: "warning" | "success" | "info" = "info") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    
    // Voice notification loop
    if (enableVoice) {
      try {
        const synth = window.speechSynthesis;
        const utterance = new SpeechSynthesisUtterance(`${title}. ${message}`);
        utterance.rate = 1.0;
        utterance.volume = 0.8;
        synth.speak(utterance);
      } catch (e) {
        console.warn("TTS synth rejected:", e);
      }
    }

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  // ==========================================
  // SYNC MULTI-TENANT REST DATA ON MOUNT / SWITCH
  // ==========================================

  const syncTenantData = async () => {
    try {
      // Set default headers carrying selected Tenant identifier
      const headers: HeadersInit = {
        "x-business-id": activeBusinessId.toString()
      };

      // 1. Fetch categories
      const resCats = await fetch("/api/categories", { headers });
      if (resCats.ok) {
        setCategories(await resCats.ok ? await resCats.json() : []);
      }

      // 2. Fetch products
      const resProducts = await fetch("/api/products", { headers });
      if (resProducts.ok) {
        const prodData = await resProducts.json();
        const mapped: Product[] = prodData.map((p: any) => ({
          id: p.id,
          name: p.name,
          category: p.categoryName || "General Store",
          price: p.sellingPrice,
          stock: p.stock,
          unit: p.unit || "pcs",
          sku: p.sku || p.barcode,
          imageUrl: p.imageUrl,
          label: p.brand
        }));
        setProducts(mapped);
      } else {
        // Fallback mock seeds when database is fresh
        seedFallbackProducts();
      }

      // 3. Fetch suppliers
      const resSuppliers = await fetch("/api/suppliers", { headers });
      if (resSuppliers.ok) setSuppliers(await resSuppliers.json());

      // 4. Fetch customers
      const resCustomers = await fetch("/api/customers", { headers });
      if (resCustomers.ok) setCustomers(await resCustomers.json());

      // 5. Fetch expenses
      const resExpenses = await fetch("/api/expenses", { headers });
      if (resExpenses.ok) setExpenses(await resExpenses.json());

      // 6. Fetch employees
      const resEmployees = await fetch("/api/employees", { headers });
      if (resEmployees.ok) setEmployees(await resEmployees.json());

      // 7. Fetch transactions
      const resHistory = await fetch("/api/history", { headers });
      if (resHistory.ok) setTransactions(await resHistory.json());

      // 8. Fetch inventory adjustments logs
      const resLogs = await fetch("/api/inventory/logs", { headers });
      if (resLogs.ok) setInventoryLogs(await resLogs.json());

    } catch (error) {
      console.warn("REST sync channel degraded. Preloading multi-tenant localized mock registers:", error);
      seedFallbackProducts();
    }
  };

  useEffect(() => {
    syncTenantData();
  }, [activeBusinessId]);

  useEffect(() => {
    const handleOnlineStatus = () => {
      setIsOnline(true);
      addToast("Database Connected", "Online mode active. Synchronizing POS with PostgreSQL.", "success");
      syncTenantData();
    };
    const handleOfflineStatus = () => {
      setIsOnline(false);
      addToast("Offline Mode Active", "Local POS safe mode. Transactions buffered offline.", "warning");
    };

    window.addEventListener("online", handleOnlineStatus);
    window.addEventListener("offline", handleOfflineStatus);

    return () => {
      window.removeEventListener("online", handleOnlineStatus);
      window.removeEventListener("offline", handleOfflineStatus);
    };
  }, []);

  // Seed standard products matching selected business types to provide perfect instantly interactive experience
  const seedFallbackProducts = () => {
    let seeds: Product[] = [];
    if (activeBusiness.businessType === "Grocery") {
      seeds = [
        { id: 101, name: "Organic Red Apples", category: "Produce", price: 2.99, stock: 45, unit: "kg", sku: "8801923", label: "NatureFarm", imageUrl: `https://picsum.photos/seed/apples/200/200`, warehouse: "Warehouse North", expiryDate: "2026-08-15" },
        { id: 102, name: "Whole Wheat Bread", category: "Bakery", price: 3.49, stock: 12, unit: "loaf", sku: "8801924", label: "DailyFresh", imageUrl: `https://picsum.photos/seed/bread/200/200`, warehouse: "Warehouse North", expiryDate: "2026-07-10" },
        { id: 103, name: "Fresh Farm Eggs (12pk)", category: "Groceries", price: 4.29, stock: 3, unit: "pack", sku: "8801925", label: "HappyHens", imageUrl: `https://picsum.photos/seed/eggs/200/200`, warehouse: "Warehouse East", expiryDate: "2026-07-20" },
        { id: 104, name: "Pure Orange Juice 1L", category: "Beverages", price: 5.99, stock: 24, unit: "pcs", sku: "8801926", label: "TropicBlend", imageUrl: `https://picsum.photos/seed/juice/200/200`, warehouse: "Warehouse South", expiryDate: "2026-09-30" }
      ];
    } else if (activeBusiness.businessType === "Fashion") {
      seeds = [
        { id: 201, name: "Classic Indigo Denim", category: "Fashion", price: 49.99, stock: 15, unit: "pcs", sku: "7720930", label: "Levis", imageUrl: `https://picsum.photos/seed/denim/200/200`, warehouse: "Fashion Depot", variants: ["S", "M", "L", "XL"] },
        { id: 202, name: "Premium Wool Coat", category: "Fashion", price: 129.99, stock: 4, unit: "pcs", sku: "7720931", label: "Zara", imageUrl: `https://picsum.photos/seed/coat/200/200`, warehouse: "Fashion Depot", variants: ["M", "L"] },
        { id: 203, name: "Retro Leather Sneakers", category: "Footwear", price: 79.99, stock: 8, unit: "pairs", sku: "7720932", label: "Adidas", imageUrl: `https://picsum.photos/seed/sneakers/200/200`, warehouse: "Shoes Depot", variants: ["8", "9", "10", "11"] }
      ];
    } else if (activeBusiness.businessType === "Pharmacy") {
      seeds = [
        { id: 301, name: "Multivitamin Gummies", category: "Wellness", price: 14.50, stock: 50, unit: "bottle", sku: "6601932", label: "Centrum", imageUrl: `https://picsum.photos/seed/vitamins/200/200`, warehouse: "Pharma Vault", expiryDate: "2027-12-31" },
        { id: 302, name: "Paracetamol 500mg (20pk)", category: "Medicine", price: 3.20, stock: 120, unit: "strip", sku: "6601933", label: "Crocin", imageUrl: `https://picsum.photos/seed/medicine/200/200`, warehouse: "Pharma Vault", expiryDate: "2026-10-31" },
        { id: 303, name: "Automated BP Monitor", category: "Devices", price: 39.99, stock: 2, unit: "pcs", sku: "6601934", label: "Omron", imageUrl: `https://picsum.photos/seed/omron/200/200`, warehouse: "Devices Rack", serialNumber: "BP-MON-771092" }
      ];
    } else {
      seeds = [
        { id: 401, name: "Truffle Fries Basket", category: "Appetizers", price: 8.99, stock: 60, unit: "plates", sku: "550923", label: "BiteKitchen", imageUrl: `https://picsum.photos/seed/fries/200/200`, warehouse: "Kitchen Fridge" },
        { id: 402, name: "Margherita Woodfired Pizza", category: "Main Course", price: 14.99, stock: 8, unit: "pcs", sku: "550924", label: "PizzaFire", imageUrl: `https://picsum.photos/seed/pizza/200/200`, warehouse: "Dough Prep Table" },
        { id: 403, name: "Craft IPA Pint", category: "Beverages", price: 6.50, stock: 110, unit: "pints", sku: "550925", label: "BrewCo", imageUrl: `https://picsum.photos/seed/beer/200/200`, warehouse: "Beer Cellar" }
      ];
    }
    setProducts(seeds);
  };

  // Exchange rate converters
  const themeStyles = AVAILABLE_THEMES.find((t) => t.id === activeTheme) || AVAILABLE_THEMES[1];

  const formatPriceLocal = (priceInUsd: number) => {
    const currentSymbol = activeBusiness.currency === "EUR" ? "€" : activeBusiness.currency === "GBP" ? "£" : activeBusiness.currency === "INR" ? "₹" : activeBusiness.currency === "JPY" ? "¥" : "$";
    if (activeBusiness.currency === "JPY") {
      return `${currentSymbol}${Math.round(priceInUsd).toLocaleString()}`;
    }
    return `${currentSymbol}${priceInUsd.toFixed(2)}`;
  };

  // ==========================================
  // REAL-TIME WEBSOCKET LISTENER
  // ==========================================

  useEffect(() => {
    let ws: WebSocket | null = null;
    const connectWs = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const host = window.location.host;
      ws = new WebSocket(`${protocol}//${host}`);

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === "stock:updated") {
            setProducts((prev) =>
              prev.map((p) => (p.id === payload.productId ? { ...p, stock: payload.stock } : p))
            );
          }
        } catch (e) {
          console.warn("WS parsing error:", e);
        }
      };

      ws.onclose = () => {
        setTimeout(connectWs, 5000); // Auto reconnect loop
      };
    };

    connectWs();
    return () => {
      ws?.close();
    };
  }, []);

  // ==========================================
  // ONBOARDING HANDLER
  // ==========================================

  const handleRegisterBusiness = async (formData: any) => {
    try {
      const response = await fetch("/api/business", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        const data = await response.json();
        const newBiz: TenantBusiness = data.business;
        setBusinessesList((prev) => [...prev, newBiz]);
        setActiveBusinessId(newBiz.id);
        addToast("Onboarding Successful!", `"${newBiz.name}" registered successfully! Seed categories provisioned.`, "success");
      } else {
        // Fallback if network fails
        const newId = businessesList.length + 1;
        const fallbackBiz: TenantBusiness = {
          id: newId,
          ...formData,
        };
        setBusinessesList((prev) => [...prev, fallbackBiz]);
        setActiveBusinessId(newId);
        addToast("Local Onboarding Active", `Created "${formData.name}" locally on browser storage.`, "info");
      }
    } catch (err) {
      console.error(err);
      const newId = businessesList.length + 1;
      const fallbackBiz: TenantBusiness = {
        id: newId,
        ...formData,
      };
      setBusinessesList((prev) => [...prev, fallbackBiz]);
      setActiveBusinessId(newId);
      addToast("Local Onboarding Activated", `Registered profile "${formData.name}" locally.`, "info");
    }
  };

  // ==========================================
  // POS CHECKOUT SYSTEM
  // ==========================================

  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      addToast("Out of Stock!", `"${product.name}" has zero inventory left.`, "warning");
      return;
    }
    setCart((prev) => {
      const match = prev.find((item) => item.product.id === product.id);
      if (match) {
        if (match.quantity >= product.stock) {
          addToast("Quantity Capped!", `Cannot sell more than ${product.stock} available units.`, "warning");
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateCartQty = (productId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + delta;
            if (nextQty > item.product.stock) {
              addToast("Quantity Capped!", `Maximum available is ${item.product.stock} units.`, "warning");
              return item;
            }
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  // Calculate totals matching Tax percentages of the tenant
  const getSubtotal = () => cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const getTaxAmount = () => getSubtotal() * (activeBusiness.taxPercentage / 100);
  const getDiscountAmount = () => {
    const rateDiscount = getSubtotal() * (discountPercent / 100);
    const matchedCustomer = customers.find((c) => c.name === selectedCustomerName);
    const loyaltyPoints = matchedCustomer ? (matchedCustomer.loyaltyPoints || 0) : 0;
    const loyaltyDiscount = redeemLoyalty ? Math.min(getSubtotal() * 0.5, loyaltyPoints * 0.10) : 0; // Cap at 50% of subtotal
    return rateDiscount + activeCouponDiscount + loyaltyDiscount;
  };
  const getTotal = () => Math.max(0, getSubtotal() + getTaxAmount() - getDiscountAmount());

  // Split payment handler helper
  const handleCheckout = async () => {
    if (cart.length === 0) {
      addToast("Cart Empty", "Please add products before checking out.", "warning");
      return;
    }

    setCheckoutLoading(true);
    const invoiceNumber = `${activeBusiness.invoicePrefix}-${Date.now().toString().substring(7)}`;

    const itemsPayload = cart.map((item) => ({
      productId: item.product.id,
      productName: item.product.name,
      quantity: item.quantity,
      price: item.product.price,
      taxAmount: item.product.price * item.quantity * (activeBusiness.taxPercentage / 100),
      discountAmount: 0
    }));

    let splitLogText = "";
    if (paymentMethod === "Split") {
      splitLogText = `Split: $${splitCashAmount || "0"} Cash + $${splitCardAmount || "0"} Card`;
    } else if (paymentMethod === "EMI") {
      splitLogText = `EMI plan: Term ${emiTerm} mo, Down payment: $${downPaymentInput || "0"}`;
    }

    const payload = {
      invoiceNumber,
      customerName: selectedCustomerName,
      subtotal: getSubtotal(),
      discount: getDiscountAmount(),
      taxAmount: getTaxAmount(),
      total: getTotal(),
      paymentMethod,
      splitDetails: splitLogText || null,
      paymentStatus: paymentMethod === "EMI" ? "Partial" : "Paid",
      operatorId: activeRole.toUpperCase(),
      items: itemsPayload,
    };

    // Loyalty points calculation
    const awardedPoints = Math.floor(getTotal() / 10);
    const matchedCustomer = customers.find((c) => c.name === selectedCustomerName);
    const customerPoints = matchedCustomer ? (matchedCustomer.loyaltyPoints || 0) : 0;
    const pointsToDeduct = redeemLoyalty ? Math.floor(Math.min(getSubtotal() * 0.5, customerPoints * 0.10) / 0.10) : 0;

    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-business-id": activeBusinessId.toString(),
        },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        const tx: Transaction = data.transaction;
        setLastTransaction(tx);
        setShowReceipt(true);
        setCart([]);
        setDiscountPercent(0);
        setActiveCouponDiscount(0);
        setCouponCodeInput("");
        setSplitCashAmount("");
        setSplitCardAmount("");
        setRedeemLoyalty(false);
        setDownPaymentInput("");
        setEmiTerm(3);

        // Update local customer profile for loyalty & EMI tracker
        if (selectedCustomerName !== "Guest Customer") {
          setCustomers((prev) =>
            prev.map((c) => {
              if (c.name === selectedCustomerName) {
                const updatedPoints = Math.max(0, (c.loyaltyPoints || 0) - pointsToDeduct + awardedPoints);
                const unpaidBalance = paymentMethod === "EMI" ? Math.max(0, getTotal() - (Number(downPaymentInput) || 0)) : 0;
                return {
                  ...c,
                  loyaltyPoints: updatedPoints,
                  outstandingBalance: (c.outstandingBalance || 0) + unpaidBalance,
                };
              }
              return c;
            })
          );
        }

        addToast("Checkout Finalized!", `Invoice #${invoiceNumber} successfully written to PostgreSQL.`, "success");
        syncTenantData(); // Refresh stock counts and ledger
      } else {
        throw new Error("API transaction failed");
      }
    } catch (e) {
      // Local Fallback simulation if DB not responsive
      const mockTx: Transaction = {
        id: Math.floor(Math.random() * 9999),
        invoiceNumber,
        customerName: selectedCustomerName,
        subtotal: getSubtotal(),
        discount: getDiscountAmount(),
        taxAmount: getTaxAmount(),
        total: getTotal(),
        paymentMethod,
        paymentStatus: paymentMethod === "EMI" ? "Partial" : "Paid",
        operatorId: activeRole.toUpperCase(),
        createdAt: new Date().toISOString(),
        items: cart.map((c, idx) => ({
          id: idx,
          transactionId: 1,
          productId: c.product.id,
          productName: c.product.name,
          quantity: c.quantity,
          price: c.product.price,
        })),
      };

      setLastTransaction(mockTx);
      setShowReceipt(true);

      // Deduct stock levels locally
      setProducts((prev) =>
        prev.map((p) => {
          const cartItem = cart.find((item) => item.product.id === p.id);
          if (cartItem) {
            const nextStock = Math.max(0, p.stock - cartItem.quantity);
            if (nextStock <= lowStockThreshold) {
              setTimeout(() => {
                addToast("Low Stock Warning!", `"${p.name}" inventory has dropped to ${nextStock} units.`, "warning");
              }, 1000);
            }
            return { ...p, stock: nextStock };
          }
          return p;
        })
      );

      // Update local customer profile for loyalty & EMI tracker
      if (selectedCustomerName !== "Guest Customer") {
        setCustomers((prev) =>
          prev.map((c) => {
            if (c.name === selectedCustomerName) {
              const updatedPoints = Math.max(0, (c.loyaltyPoints || 0) - pointsToDeduct + awardedPoints);
              const unpaidBalance = paymentMethod === "EMI" ? Math.max(0, getTotal() - (Number(downPaymentInput) || 0)) : 0;
              return {
                ...c,
                loyaltyPoints: updatedPoints,
                outstandingBalance: (c.outstandingBalance || 0) + unpaidBalance,
              };
            }
            return c;
          })
        );
      }

      setTransactions((prev) => [mockTx, ...prev]);
      setCart([]);
      setDiscountPercent(0);
      setActiveCouponDiscount(0);
      setCouponCodeInput("");
      setSplitCashAmount("");
      setSplitCardAmount("");
      setRedeemLoyalty(false);
      setDownPaymentInput("");
      setEmiTerm(3);
      addToast("POS Invoice Spooled", `Checked out Invoice #${invoiceNumber} successfully (Offline Mode).`, "info");
    } finally {
      setCheckoutLoading(false);
    }
  };

  // Validate coupon codes
  const handleApplyCoupon = () => {
    const code = couponCodeInput.trim().toUpperCase();
    if (code === "WELCOME10") {
      setActiveCouponDiscount(10);
      addToast("Promo Code Active!", "WELCOME10 applied: $10 flat reduction granted.", "success");
    } else if (code === "SUPERPOS") {
      setActiveCouponDiscount(15);
      addToast("Promo Code Active!", "SUPERPOS applied: $15 flat reduction granted.", "success");
    } else if (code === "SAVE5") {
      setDiscountPercent(5);
      addToast("Promo Code Active!", "SAVE5 applied: 5% total discount granted.", "success");
    } else {
      addToast("Invalid Code!", "This coupon code does not exist or has expired.", "warning");
    }
  };

  // Simulate barcode scanner triggers
  const handleSimulatedScan = () => {
    if (!scanSkuInput) {
      setScanStatus("Please input a barcode SKU.");
      return;
    }
    const match = products.find((p) => p.sku === scanSkuInput || String(p.id) === scanSkuInput);
    if (match) {
      handleAddToCart(match);
      setScanStatus(`Scanned and added "${match.name}" to cart!`);
      setScanSkuInput("");
      setTimeout(() => setScanStatus(null), 3000);
    } else {
      setScanStatus("Product SKU not found in store catalog.");
    }
  };

  // ==========================================
  // EXPENSES CREATION API
  // ==========================================
  const [expenseTitle, setExpenseTitle] = useState("");
  const [expenseAmount, setExpenseAmount] = useState("");
  const [expenseCategory, setExpenseCategory] = useState("Rent");
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split("T")[0]);

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseTitle || !expenseAmount) return;

    const payload = {
      title: expenseTitle,
      amount: Number(expenseAmount),
      category: expenseCategory,
      date: expenseDate,
    };

    try {
      const res = await fetch("/api/expenses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-business-id": activeBusinessId.toString()
        },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        addToast("Expense Voucher Added", `Logged $${expenseAmount} for ${expenseTitle}.`, "success");
        setExpenseTitle("");
        setExpenseAmount("");
        syncTenantData();
      }
    } catch {
      // Local fallback
      const mockExp = {
        id: Math.random(),
        ...payload,
        createdAt: new Date().toISOString()
      };
      setExpenses((prev) => [mockExp, ...prev]);
      setExpenseTitle("");
      setExpenseAmount("");
      addToast("Local Expense Logged", `Logged ${expenseTitle} on browser cache.`, "info");
    }
  };

  // ==========================================
  // STAFF RECORD ADDITION
  // ==========================================
  const [empName, setEmpName] = useState("");
  const [empRole, setEmpRole] = useState("Cashier");
  const [empSalary, setEmpSalary] = useState("");

  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!empName || !empSalary) return;

    const payload = {
      name: empName,
      role: empRole,
      salary: Number(empSalary),
    };

    try {
      const res = await fetch("/api/employees", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-business-id": activeBusinessId.toString()
        },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        addToast("Staff File Generated", `Created employee profile for ${empName}.`, "success");
        setEmpName("");
        setEmpSalary("");
        syncTenantData();
      }
    } catch {
      const mockEmp = {
        id: Math.random(),
        ...payload,
        attendanceJson: "{}",
        createdAt: new Date().toISOString()
      };
      setEmployees((prev) => [mockEmp, ...prev]);
      setEmpName("");
      setEmpSalary("");
      addToast("Local Staff Logged", `Registered ${empName} profile.`, "info");
    }
  };

  // ==========================================
  // PRINTER NETWORK UTILITIES
  // ==========================================
  const handleAddPrinterLocal = () => {
    if (!newPrinterName || !newPrinterIp) return;
    const newP = {
      id: "p_" + Math.random().toString(36).substring(2, 9),
      name: newPrinterName,
      ip: newPrinterIp,
      port: Number(newPrinterPort) || 9100,
      isDefault: false,
      status: "ONLINE"
    };
    setPrinters((prev) => [...prev, newP]);
    setNewPrinterName("");
    setNewPrinterIp("");
    addToast("Thermal Printer Registered", `Configured ${newPrinterName} over IP: ${newPrinterIp}`, "success");
  };

  const handleSetDefaultPrinter = (id: string) => {
    setPrinters((prev) => prev.map((p) => ({ ...p, isDefault: p.id === id })));
    addToast("Default Printer Updated", "Preferred terminal routing updated.", "info");
  };

  const handleTestPrinterLocal = async (printer: any) => {
    try {
      const res = await fetch("/api/printer/print", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ip: printer.ip,
          port: printer.port,
          rawText: printer.rawText || `=== TEST SPUR SUCCESS ===\nPRINTER: ${printer.name}\nIP: ${printer.ip}:${printer.port}\n\n`
        })
      });
      if (res.ok) {
        addToast("ESC/POS Spooled", `Sent print buffers to printer ${printer.name} successfully.`, "success");
      } else {
        addToast("Mock Spool Completed", `Simulated network print stream to ${printer.name} at ${printer.ip}.`, "info");
      }
    } catch {
      addToast("Mock Spool Generated", `Spool feedback active for ${printer.name} at 127.0.0.1.`, "info");
    }
  };

  const handleScanPrintersNetwork = async () => {
    setIsScanningPrinters(true);
    try {
      const res = await fetch("/api/printer/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ printers })
      });
      if (res.ok) {
        const data = await res.json();
        setPrinters(data.results);
        addToast("Printers Scan Completed", "Refreshed live statuses for all local network terminals.", "success");
      }
    } catch {
      addToast("Scan Spool Simulated", "Scanning network ports for thermal ports... Online.", "info");
    } finally {
      setIsScanningPrinters(false);
    }
  };

  // Filtered store catalog
  const filteredProducts = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(productSearch.toLowerCase()) || p.sku.toLowerCase().includes(productSearch.toLowerCase());
    const matchCat = selectedCategoryFilter === "All" || p.category === selectedCategoryFilter;
    return matchSearch && matchCat;
  });

  const handleSendChatMessage = async () => {
    if (!chatInput.trim()) return;
    const userText = chatInput;
    setChatInput("");
    setChatMessages((prev) => [...prev, { role: "user", text: userText }]);
    setChatLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-business-id": activeBusinessId.toString(),
        },
        body: JSON.stringify({ message: userText }),
      });

      if (res.ok) {
        const data = await res.json();
        setChatMessages((prev) => [...prev, { role: "model", text: data.reply }]);
      } else {
        throw new Error("API chatbot degraded");
      }
    } catch {
      // Local smart fallback matching the queries
      let fallbackReply = "I am having trouble connecting to the Postgres server. Here is a local estimate: everything looks fully healthy! Low stock is monitored on your dashboard.";
      const lower = userText.toLowerCase();
      if (lower.includes("sales") || lower.includes("revenue") || lower.includes("today")) {
        fallbackReply = `Today's total checkout volume is **${formatPriceLocal(transactions.reduce((acc, t) => acc + t.total, 0))}** spanning **${transactions.length} orders**. Fully recorded!`;
      } else if (lower.includes("low") || lower.includes("stock") || lower.includes("inventory")) {
        const low = products.filter(p => p.stock <= lowStockThreshold);
        if (low.length > 0) {
          fallbackReply = `⚠️ **Low Stock Alert**: The following products require replenishment:\n` + low.map(p => `- **${p.name}**: ${p.stock} units remaining (Min: ${p.minStock || 5})`).join("\n");
        } else {
          fallbackReply = `✅ All inventory levels are fully healthy and above warning thresholds!`;
        }
      } else if (lower.includes("best") || lower.includes("top")) {
        fallbackReply = `Our current top-performing item by transaction logs is **${products[0]?.name || "Organic Red Apples"}** showing high client rotation index!`;
      }
      setChatMessages((prev) => [...prev, { role: "model", text: fallbackReply }]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans" id="chronos-pos-fullstack-app">
      {/* 1. Header Navigation HUD */}
      <header className={`${themeStyles.primary} text-white px-6 py-4 flex items-center justify-between shadow-lg sticky top-0 z-40`}>
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-xl backdrop-blur-md">
            <ShoppingBag className="w-6 h-6 text-white animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black tracking-tight uppercase">Chronos SaaS</h1>
              <span className="px-1.5 py-0.5 bg-yellow-400 text-slate-900 text-[9px] font-extrabold rounded uppercase tracking-wider">v2.1 PRO</span>
              <span className={`px-2 py-0.5 text-[8px] font-black rounded uppercase tracking-wider flex items-center gap-1.5 shrink-0 shadow-sm ${
                isOnline ? "bg-emerald-500 text-white" : "bg-rose-500 text-white animate-pulse"
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-white block" />
                <span>{isOnline ? "Cloud Sync" : "Offline safe"}</span>
              </span>
            </div>
            <p className="text-xs text-indigo-100 font-medium">Multi-Tenant POS & Billing Architecture</p>
          </div>
        </div>

        {/* Global Nav tabs */}
        <nav className="hidden lg:flex items-center gap-1 bg-white/10 p-1 rounded-xl backdrop-blur-md">
          {[
            { id: "store", label: "POS Billing", icon: ShoppingBag, roles: ["super_admin", "owner", "manager", "cashier"] },
            { id: "dashboard", label: "Dashboard", icon: TrendingUp, roles: ["super_admin", "owner", "manager"] },
            { id: "inventory", label: "Products", icon: Package, roles: ["super_admin", "owner", "manager"] },
            { id: "categories", label: "Categories", icon: Layers, roles: ["super_admin", "owner", "manager"] },
            { id: "customers", label: "Customers", icon: Users, roles: ["super_admin", "owner", "manager", "cashier"] },
            { id: "suppliers", label: "Suppliers", icon: Truck, roles: ["super_admin", "owner", "manager"] },
            { id: "expenses", label: "Expenses", icon: DollarSign, roles: ["super_admin", "owner"] },
            { id: "employees", label: "Employees", icon: Briefcase, roles: ["super_admin", "owner"] },
            { id: "settings", label: "Settings", icon: Sliders, roles: ["super_admin", "owner", "manager"] },
          ]
            .filter((tab) => tab.roles.includes(activeRole))
            .map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-extrabold rounded-lg transition-all ${
                  activeTab === tab.id
                    ? "bg-white text-slate-900 shadow"
                    : "text-white/80 hover:bg-white/10 hover:text-white"
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            ))}
        </nav>

        {/* Audio control & User display */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setEnableVoice(!enableVoice)}
            className="p-2 bg-white/15 hover:bg-white/20 rounded-xl text-white transition-colors"
            title="Toggle Voice Alerts"
          >
            {enableVoice ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          
          <div className="flex items-center gap-2 border-l border-white/20 pl-3">
            <div className="w-8 h-8 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center font-bold text-sm uppercase">
              {activeRole.substring(0, 2)}
            </div>
            <div className="hidden md:block text-left text-xs">
              <span className="font-bold block text-white capitalize">{activeRole} mode</span>
              <span className="text-indigo-200 uppercase tracking-widest text-[9px]">{activeBusiness.invoicePrefix} Terminal</span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile nav indicator bar */}
      <div className="lg:hidden bg-slate-800 text-slate-200 overflow-x-auto whitespace-nowrap p-2 flex gap-1 border-b border-slate-700">
        {[
          { id: "store", label: "POS" },
          { id: "dashboard", label: "Dashboard" },
          { id: "inventory", label: "Products" },
          { id: "categories", label: "Categories" },
          { id: "customers", label: "Customers" },
          { id: "suppliers", label: "Suppliers" },
          { id: "expenses", label: "Expenses" },
          { id: "employees", label: "Employees" },
          { id: "settings", label: "Settings" }
        ]
          .map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg ${activeTab === tab.id ? "bg-indigo-600 text-white" : "hover:bg-slate-700"}`}
            >
              {tab.label}
            </button>
          ))}
      </div>

      {/* Main Grid Workspace */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {/* Onboarding Wizard Hud */}
        <SaaSOnboarding
          activeBusiness={activeBusiness}
          availableBusinesses={businessesList}
          activeRole={activeRole}
          onSwitchBusiness={setActiveBusinessId}
          onSwitchRole={setActiveRole}
          onRegisterBusiness={handleRegisterBusiness}
          isAdminUnlocked={true}
          onUnlockAdmin={() => true}
        />

        {/* Tab view routes */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="space-y-6"
          >
            {/* TAB: POS BILLING SCREEN */}
            {activeTab === "store" && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="pos-billing-tab">
                {/* Store Catalog & Search Section */}
                <div className="lg:col-span-2 space-y-4">
                  <div className="bg-white p-4 rounded-2xl border border-slate-100 flex flex-col md:flex-row gap-3 items-center justify-between shadow-sm">
                    {/* Search field */}
                    <div className="relative w-full md:w-72">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        value={productSearch}
                        onChange={(e) => setProductSearch(e.target.value)}
                        placeholder="Search product name or SKU..."
                        className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>

                    {/* Barcode scanner simulator HUD */}
                    <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                      <button
                        onClick={() => setShowScanner(!showScanner)}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                          showScanner ? "bg-amber-50 border-amber-200 text-amber-700 animate-pulse" : "bg-white hover:bg-slate-50 text-slate-600"
                        }`}
                      >
                        <QrCode className="w-4 h-4 text-slate-500" />
                        <span>{showScanner ? "Active Scanner" : "Simulate Barcode"}</span>
                      </button>
                    </div>
                  </div>

                  {/* Simulator scanner console */}
                  {showScanner && (
                    <div className="bg-slate-900 text-emerald-400 p-4 rounded-2xl border border-slate-800 font-mono text-xs flex flex-col sm:flex-row gap-3 items-center justify-between shadow">
                      <div className="flex items-center gap-2">
                        <Radar className="w-5 h-5 text-emerald-400 animate-spin" />
                        <div>
                          <span className="font-bold block uppercase text-white tracking-widest text-[9px]">SaaS Scanned Laser</span>
                          <span className="text-[10px] text-slate-400">Scan items using catalog SKUs (e.g., 8801923, 7720930, 6601932)</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={scanSkuInput}
                          onChange={(e) => setScanSkuInput(e.target.value)}
                          placeholder="Type SKU barcode..."
                          onKeyDown={(e) => e.key === "Enter" && handleSimulatedScan()}
                          className="px-3 py-1.5 bg-slate-800 border border-slate-700 text-white rounded-lg text-xs focus:outline-none w-36 font-mono"
                        />
                        <button
                          onClick={handleSimulatedScan}
                          className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-lg transition-colors"
                        >
                          Trigger Laser
                        </button>
                      </div>
                      {scanStatus && <div className="text-[10px] bg-slate-800 px-3 py-1 rounded text-yellow-400 max-w-full text-center">{scanStatus}</div>}
                    </div>
                  )}

                  {/* Products Catalog Display Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                    {filteredProducts.map((prod) => (
                      <div
                        key={prod.id}
                        onClick={() => handleAddToCart(prod)}
                        className={`bg-white border hover:border-indigo-300 hover:shadow-md rounded-2xl p-4 transition-all cursor-pointer flex flex-col justify-between ${
                          prod.stock <= 0 ? "opacity-60 border-rose-100 bg-rose-50/15" : "border-slate-100"
                        }`}
                      >
                        <div>
                          <div className="relative h-28 w-full bg-slate-50 rounded-xl overflow-hidden mb-3 border border-slate-100">
                            <img
                              src={prod.imageUrl || `https://picsum.photos/seed/${prod.name}/200/200`}
                              alt={prod.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            {prod.stock <= (prod.stock >= 0 ? lowStockThreshold : 5) && (
                              <span className="absolute top-2 left-2 bg-rose-500 text-white text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md flex items-center gap-0.5 animate-bounce shadow">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                <span>Low stock ({prod.stock})</span>
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold block uppercase">{prod.category}</span>
                          <h4 className="text-sm font-extrabold text-slate-800 tracking-tight line-clamp-1 mt-0.5">{prod.name}</h4>
                          <span className="text-[10px] text-slate-400 block font-mono">SKU: {prod.sku}</span>
                        </div>
                        
                        <div className="flex items-center justify-between mt-4 border-t pt-2 border-slate-50">
                          <span className="text-base font-black text-slate-800">{formatPriceLocal(prod.price)}</span>
                          <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-xl">
                            + Add to cart
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Column: Checkout Billing sidebar */}
                <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-5 flex flex-col justify-between h-[80vh] sticky top-24">
                  <div>
                    <div className="flex items-center justify-between border-b pb-3 mb-3">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-800">Checkout Cart</h3>
                        <p className="text-[10px] text-slate-400">Invoice: #{activeBusiness.invoicePrefix}-Live</p>
                      </div>
                      <button
                        onClick={() => setCart([])}
                        className="text-xs font-bold text-slate-400 hover:text-slate-600 flex items-center gap-0.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Clear</span>
                      </button>
                    </div>

                    {/* Customer Selection block */}
                    <div className="mb-3 bg-slate-50 p-2 rounded-xl border border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <User className="w-4 h-4 text-indigo-500 shrink-0" />
                        <select
                          value={selectedCustomerName}
                          onChange={(e) => setSelectedCustomerName(e.target.value)}
                          className="bg-transparent font-bold text-xs text-slate-700 focus:outline-none"
                        >
                          <option value="Guest Customer">Guest Customer (Walk-in)</option>
                          <option value="Alice Johnson">Alice Johnson (Gold Club)</option>
                          <option value="David Miller">David Miller (Privilege)</option>
                          <option value="Siddharth Roy">Siddharth Roy (VIP Ledger)</option>
                        </select>
                      </div>
                      <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded-full font-bold">Loyalty active</span>
                    </div>

                    {/* Cart Items Spool list */}
                    <div className="space-y-2 overflow-y-auto max-h-[30vh] pr-1">
                      {cart.length === 0 ? (
                        <div className="text-center py-12 text-slate-400 text-xs flex flex-col items-center gap-2">
                          <ShoppingBag className="w-8 h-8 text-slate-200" />
                          <span>POS Cart is empty. Add items from the catalog.</span>
                        </div>
                      ) : (
                        cart.map((item) => (
                          <div key={item.product.id} className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                            <div className="flex items-center justify-between">
                              <div className="max-w-[60%]">
                                <span className="font-bold text-slate-700 block truncate" title={item.product.name}>
                                  {item.product.name}
                                </span>
                                <div className="flex flex-wrap gap-1 mt-0.5">
                                  <span className="text-[9px] px-1.5 py-0.2 bg-white text-slate-500 rounded border border-slate-150">
                                    {formatPriceLocal(item.product.price)}
                                  </span>
                                  {item.product.warehouse && (
                                    <span className="text-[8px] px-1 bg-amber-50 text-amber-700 rounded border border-amber-100 uppercase font-bold" title="Storage Location">
                                      {item.product.warehouse}
                                    </span>
                                  )}
                                  {item.product.expiryDate && (
                                    <span className="text-[8px] px-1 bg-rose-50 text-rose-700 rounded border border-rose-100 font-bold" title="Expiry date alert">
                                      Exp: {item.product.expiryDate}
                                    </span>
                                  )}
                                  {item.product.serialNumber && (
                                    <span className="text-[8px] px-1 bg-teal-50 text-teal-700 rounded border border-teal-100 font-mono font-bold" title="Device IMEI/Serial Number">
                                      IMEI: {item.product.serialNumber}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleUpdateCartQty(item.product.id, -1)}
                                  className="p-1 hover:bg-slate-200 rounded-md"
                                >
                                  <Minus className="w-3.5 h-3.5 text-slate-500" />
                                </button>
                                <span className="font-bold font-mono text-slate-800">{item.quantity}</span>
                                <button
                                  type="button"
                                  onClick={() => handleUpdateCartQty(item.product.id, 1)}
                                  className="p-1 hover:bg-slate-200 rounded-md"
                                >
                                  <Plus className="w-3.5 h-3.5 text-slate-500" />
                                </button>
                              </div>
                              <span className="font-bold text-slate-800 shrink-0">{formatPriceLocal(item.product.price * item.quantity)}</span>
                            </div>

                            {/* Item variants rendering if present */}
                            {item.product.variants && item.product.variants.length > 0 && (
                              <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-100 text-[10px]">
                                <span className="text-slate-400 font-bold text-[9px] uppercase px-1">Variant:</span>
                                <div className="flex gap-1 overflow-x-auto">
                                  {item.product.variants.map((v) => {
                                    const isSel = (item as any).selectedVariant === v || (!(item as any).selectedVariant && item.product.variants?.[0] === v);
                                    return (
                                      <button
                                        key={v}
                                        type="button"
                                        onClick={() => {
                                          setCart((prev) =>
                                            prev.map((c) =>
                                              c.product.id === item.product.id ? ({ ...c, selectedVariant: v } as any) : c
                                            )
                                          );
                                          addToast("Variant Selected", `Variant "${v}" selected for ${item.product.name}.`, "info");
                                        }}
                                        className={`px-2 py-0.5 rounded text-[8px] font-bold ${
                                          isSel ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                                        }`}
                                      >
                                        {v}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Calculations, Split selection, coupons, and checkout buttons */}
                  <div className="border-t pt-3 mt-3 space-y-3">
                    {/* Coupons and promo codes */}
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={couponCodeInput}
                        onChange={(e) => setCouponCodeInput(e.target.value)}
                        placeholder="WELCOME10, SUPERPOS..."
                        className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none uppercase font-mono"
                      />
                      <button
                        onClick={handleApplyCoupon}
                        className="bg-slate-800 hover:bg-slate-900 text-white px-3 py-1.5 text-xs font-bold rounded-xl transition-all"
                      >
                        Apply
                      </button>
                    </div>

                    {/* Loyalty Points redemption check if a customer is selected */}
                    {selectedCustomerName !== "Guest Customer" && (
                      <div className="flex justify-between items-center text-xs bg-indigo-50/50 p-2 rounded-xl border border-indigo-100/40">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="checkbox"
                            id="redeem-loyalty"
                            checked={redeemLoyalty}
                            onChange={(e) => setRedeemLoyalty(e.target.checked)}
                            className="rounded border-indigo-300 text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
                          />
                          <label htmlFor="redeem-loyalty" className="font-semibold text-slate-700 cursor-pointer text-[11px]">
                            Redeem Loyalty Credit
                          </label>
                        </div>
                        <span className="text-[10px] text-slate-500 font-bold bg-white px-2 py-0.5 rounded-full border border-indigo-100">
                          Bal: {customers.find(c => c.name === selectedCustomerName)?.loyaltyPoints || 0} pts
                        </span>
                      </div>
                    )}

                    {/* Method & Split Payments */}
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-500">Method:</span>
                        <div className="flex flex-wrap gap-1 justify-end max-w-[80%]">
                          {["UPI", "Card", "Cash", "Split", "EMI"].map((m) => (
                            <button
                              key={m}
                              type="button"
                              onClick={() => setPaymentMethod(m as any)}
                              className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                                paymentMethod === m ? "bg-indigo-600 text-white" : "bg-white border text-slate-600 hover:bg-slate-50"
                              }`}
                            >
                              {m}
                            </button>
                          ))}
                        </div>
                      </div>

                      {paymentMethod === "Split" && (
                        <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-200">
                          <div>
                            <span className="text-[9px] font-bold text-slate-400 block uppercase">Cash Amount</span>
                            <input
                              type="number"
                              value={splitCashAmount}
                              onChange={(e) => setSplitCashAmount(e.target.value)}
                              placeholder="$0.00"
                              className="w-full px-2 py-1 text-xs bg-white border rounded focus:outline-none"
                            />
                          </div>
                          <div>
                            <span className="text-[9px] font-bold text-slate-400 block uppercase">Card Amount</span>
                            <input
                              type="number"
                              value={splitCardAmount}
                              onChange={(e) => setSplitCardAmount(e.target.value)}
                              placeholder="$0.00"
                              className="w-full px-2 py-1 text-xs bg-white border rounded focus:outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {paymentMethod === "EMI" && (
                        <div className="space-y-2 pt-1.5 border-t border-slate-200 text-xs">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] text-slate-500 font-bold">EMI Term:</span>
                            <div className="flex gap-1">
                              {[3, 6, 12].map((term) => (
                                <button
                                  key={term}
                                  type="button"
                                  onClick={() => setEmiTerm(term)}
                                  className={`px-2 py-0.5 rounded text-[10px] ${
                                    emiTerm === term ? "bg-slate-800 text-white font-bold" : "bg-white border text-slate-600"
                                  }`}
                                >
                                  {term}M
                                </button>
                              ))}
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 block uppercase">Down Payment</span>
                              <input
                                type="number"
                                value={downPaymentInput}
                                onChange={(e) => setDownPaymentInput(e.target.value)}
                                placeholder="$0.00"
                                className="w-full px-2 py-1 text-xs bg-white border rounded focus:outline-none"
                              />
                            </div>
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 block uppercase">Monthly EMI</span>
                              <div className="px-2 py-1 bg-slate-100 text-slate-700 rounded font-bold text-[10px] truncate">
                                {formatPriceLocal(Math.max(0, (getTotal() - (Number(downPaymentInput) || 0)) / emiTerm))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Totals Summary */}
                    <div className="space-y-1.5 text-xs font-medium border-t pt-2">
                      <div className="flex justify-between text-slate-500">
                        <span>Items Base:</span>
                        <span>{formatPriceLocal(getSubtotal())}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Discounts:</span>
                        <span className="text-rose-500">-{formatPriceLocal(getDiscountAmount())}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>SaaS Tax ({activeBusiness.taxPercentage}%):</span>
                        <span>{formatPriceLocal(getTaxAmount())}</span>
                      </div>
                      <div className="flex justify-between font-black text-slate-800 text-base border-t pt-1.5">
                        <span>TOTAL NET:</span>
                        <span className={themeStyles.text}>{formatPriceLocal(getTotal())}</span>
                      </div>
                    </div>

                    <button
                      onClick={handleCheckout}
                      disabled={checkoutLoading}
                      className={`w-full ${themeStyles.btn} disabled:bg-slate-300 text-white py-3 rounded-2xl text-xs font-black shadow-lg uppercase tracking-wider transition-all`}
                    >
                      {checkoutLoading ? "Writing Transaction..." : "Issue Tax Invoice"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SAAS DASHBOARD & RECHARTS */}
            {activeTab === "dashboard" && (
              <SaasDashboard
                products={products}
                transactions={transactions}
                expenses={expenses}
                customersCount={customers.length > 0 ? customers.length : 3}
                employeesCount={employees.length > 0 ? employees.length : 2}
                formatPrice={formatPriceLocal}
                lowStockThreshold={lowStockThreshold}
                activeBusinessName={activeBusiness.name}
              />
            )}

            {/* TAB: PRODUCT INVENTORY CATALOG */}
            {activeTab === "inventory" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="products-catalog-tab">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Master Product Catalog</h3>
                    <p className="text-xs text-slate-400">Edit or register product items directly under {activeBusiness.name} database namespace</p>
                  </div>
                </div>

                <InventoryManager
                  onProductCreated={syncTenantData}
                  activeBusinessId={activeBusinessId}
                />
              </div>
            )}

            {/* TAB: CATEGORIES MANAGER */}
            {activeTab === "categories" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="categories-tab">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Category Catalog Nests</h3>
                    <p className="text-xs text-slate-400">Manage hierarchical departments (categories & subcategories)</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Create category Form */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Create Category</h4>
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const name = (e.currentTarget.elements.namedItem("catName") as HTMLInputElement).value;
                        const parent = (e.currentTarget.elements.namedItem("catParent") as HTMLSelectElement).value;
                        try {
                          await fetch("/api/categories", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", "x-business-id": activeBusinessId.toString() },
                            body: JSON.stringify({ name, parentId: parent || null })
                          });
                          addToast("Category Added", `"${name}" registered successfully under business ID ${activeBusinessId}.`, "success");
                          syncTenantData();
                          (e.target as any).reset();
                        } catch {
                          addToast("Sync Degraded", "Wrote local category.", "info");
                        }
                      }}
                      className="space-y-4 text-xs font-semibold"
                    >
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Category Name *</label>
                        <input
                          type="text"
                          name="catName"
                          required
                          placeholder="e.g. Organic Produce"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Parent Hierarchy (Nesting)</label>
                        <select
                          name="catParent"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium text-slate-600 focus:outline-none"
                        >
                          <option value="">None (Primary Department)</option>
                          {categories.map((c) => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                      <button
                        type="submit"
                        className={`w-full ${themeStyles.btn} text-white py-2 rounded-xl font-bold transition-all`}
                      >
                        Save Department
                      </button>
                    </form>
                  </div>

                  {/* Registered lists */}
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Registered Departments</h4>
                    <div className="space-y-2">
                      {categories.length === 0 ? (
                        <span className="text-xs text-slate-400 block text-center py-12">No categories found. Standard seeds loaded during POS checkout fallback.</span>
                      ) : (
                        categories.map((cat) => (
                          <div key={cat.id} className="flex justify-between items-center text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                            <div>
                              <span className="font-bold text-slate-700">{cat.name}</span>
                              {cat.parentId && <span className="text-[9px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded ml-2">Nesting Node</span>}
                            </div>
                            <button
                              onClick={async () => {
                                await fetch(`/api/categories/${cat.id}`, {
                                  method: "DELETE",
                                  headers: { "x-business-id": activeBusinessId.toString() }
                                });
                                syncTenantData();
                                addToast("Category Removed", `Removed ${cat.name} from index.`, "info");
                              }}
                              className="text-rose-500 hover:text-rose-700 font-bold"
                            >
                              Delete
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: CUSTOMER PROFILES */}
            {activeTab === "customers" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="customers-tab">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Loyalty Customer Ledger</h3>
                    <p className="text-xs text-slate-400">Manage member directories, purchase histories, loyalty points, and outstanding balances</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Create Customer */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 h-fit">
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Register Loyalty Customer</h4>
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const name = (e.currentTarget.elements.namedItem("cName") as HTMLInputElement).value;
                        const phone = (e.currentTarget.elements.namedItem("cPhone") as HTMLInputElement).value;
                        const email = (e.currentTarget.elements.namedItem("cEmail") as HTMLInputElement).value;
                        const address = (e.currentTarget.elements.namedItem("cAddress") as HTMLTextAreaElement).value;

                        const payload = { name, phone, email, address, loyaltyPoints: 10, outstandingBalance: 0 };
                        try {
                          await fetch("/api/customers", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", "x-business-id": activeBusinessId.toString() },
                            body: JSON.stringify(payload)
                          });
                          addToast("Customer Profile Active", `Created loyalty directory for ${name}.`, "success");
                          syncTenantData();
                          (e.target as any).reset();
                        } catch {
                          setCustomers((prev) => [...prev, { id: Math.random(), ...payload }]);
                          addToast("Local Profile Saved", "Customer registered in cache.", "info");
                        }
                      }}
                      className="space-y-4 text-xs font-semibold"
                    >
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Customer Name *</label>
                        <input type="text" name="cName" required className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Phone Number</label>
                        <input type="text" name="cPhone" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Email Address</label>
                        <input type="email" name="cEmail" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Physical Address</label>
                        <textarea name="cAddress" rows={2} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <button type="submit" className={`w-full ${themeStyles.btn} text-white py-2 rounded-xl font-bold transition-all`}>
                        Register Customer
                      </button>
                    </form>
                  </div>

                  {/* Customer Lists */}
                  <div className="lg:col-span-2 space-y-4">
                    <h4 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider">Registered Loyalty Directories</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {customers.length === 0 ? (
                        <div className="col-span-2 text-center py-12 text-slate-400 text-xs">
                          No specific profiles registered. Default guest walk-in is loaded during checkout checkout.
                        </div>
                      ) : (
                        customers.map((c) => (
                          <div key={c.id} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 flex flex-col justify-between">
                            <div>
                              <h5 className="font-extrabold text-slate-800 text-sm">{c.name}</h5>
                              <span className="text-[10px] text-slate-400 block mt-0.5">{c.phone || "No phone listed"}</span>
                              <span className="text-[10px] text-slate-400 block">{c.email || "No email listed"}</span>
                            </div>
                            <div className="mt-4 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                              <span className="text-indigo-600 font-bold">Points: {c.loyaltyPoints || 0} pts</span>
                              <span className="text-rose-600 font-bold">Outstanding: {formatPriceLocal(Number(c.outstandingBalance || 0))}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SUPPLIER SHEET */}
            {activeTab === "suppliers" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="suppliers-tab">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Procurement Supplier Sheets</h3>
                    <p className="text-xs text-slate-400">Review supplier directories, payments status, and outstanding amount balances</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Register Supplier form */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 h-fit">
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Add Supplier Record</h4>
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const name = (e.currentTarget.elements.namedItem("sName") as HTMLInputElement).value;
                        const contactPerson = (e.currentTarget.elements.namedItem("sContact") as HTMLInputElement).value;
                        const phone = (e.currentTarget.elements.namedItem("sPhone") as HTMLInputElement).value;
                        const email = (e.currentTarget.elements.namedItem("sEmail") as HTMLInputElement).value;
                        const outstandingAmount = (e.currentTarget.elements.namedItem("sOutstanding") as HTMLInputElement).value;

                        const payload = { name, contactPerson, phone, email, outstandingAmount: Number(outstandingAmount) || 0 };
                        try {
                          await fetch("/api/suppliers", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", "x-business-id": activeBusinessId.toString() },
                            body: JSON.stringify(payload)
                          });
                          addToast("Supplier Catalog Added", `Registered ${name} successfully in database.`, "success");
                          syncTenantData();
                          (e.target as any).reset();
                        } catch {
                          setSuppliers((prev) => [...prev, { id: Math.random(), ...payload }]);
                          addToast("Local Supplier Logged", "Saved to local cache.", "info");
                        }
                      }}
                      className="space-y-4 text-xs font-semibold"
                    >
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Supplier Name *</label>
                        <input type="text" name="sName" required className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Contact Person</label>
                        <input type="text" name="sContact" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Phone</label>
                        <input type="text" name="sPhone" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Email</label>
                        <input type="email" name="sEmail" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Initial Outstanding Amount</label>
                        <input type="number" name="sOutstanding" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <button type="submit" className={`w-full ${themeStyles.btn} text-white py-2 rounded-xl font-bold transition-all`}>
                        Save Supplier Profile
                      </button>
                    </form>
                  </div>

                  {/* Lists */}
                  <div className="lg:col-span-2 space-y-4">
                    <h4 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider">Active Suppliers Directory</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {suppliers.length === 0 ? (
                        <div className="col-span-2 text-center py-12 text-slate-400 text-xs">
                          No procurement suppliers currently configured. Open settings or add custom entries.
                        </div>
                      ) : (
                        suppliers.map((s) => (
                          <div key={s.id} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 flex flex-col justify-between">
                            <div>
                              <h5 className="font-extrabold text-slate-800 text-sm">{s.name}</h5>
                              <p className="text-[10px] text-slate-400">Contact: {s.contactPerson || "Direct Support"}</p>
                              <p className="text-[10px] text-slate-400">Phone: {s.phone || "N/A"}</p>
                              <p className="text-[10px] text-indigo-500 font-semibold">{s.email}</p>
                            </div>
                            <div className="mt-4 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                              <span className="text-slate-500">Payments Outstanding</span>
                              <span className="text-rose-600 font-bold">{formatPriceLocal(Number(s.outstandingAmount || 0))}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: EXPENSES SHEETS */}
            {activeTab === "expenses" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="expenses-tab">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Operational Expense Sheets</h3>
                    <p className="text-xs text-slate-400">Log company expenditures (utilities, rents, inventory acquisitions, marketing, etc.)</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* form */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 h-fit">
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Log Expense Voucher</h4>
                    <form onSubmit={handleAddExpense} className="space-y-4 text-xs font-semibold">
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Expense Title *</label>
                        <input type="text" required value={expenseTitle} onChange={(e) => setExpenseTitle(e.target.value)} placeholder="e.g. Server hosting, electricity bill" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Expenditure Amount *</label>
                        <input type="number" required value={expenseAmount} onChange={(e) => setExpenseAmount(e.target.value)} placeholder="0.00" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Voucher Category</label>
                        <select value={expenseCategory} onChange={(e) => setExpenseCategory(e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none text-slate-600">
                          <option value="Rent">Rent</option>
                          <option value="Utilities">Utilities</option>
                          <option value="Salary">Salary</option>
                          <option value="Inventory">Inventory Acquisition</option>
                          <option value="Marketing">Marketing & Ads</option>
                          <option value="Other">Other Miscellaneous</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Transaction Date</label>
                        <input type="date" value={expenseDate} onChange={(e) => setExpenseDate(e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none text-slate-600" />
                      </div>
                      <button type="submit" className={`w-full ${themeStyles.btn} text-white py-2 rounded-xl font-bold transition-all`}>
                        Record Voucher
                      </button>
                    </form>
                  </div>

                  {/* Lists */}
                  <div className="lg:col-span-2 space-y-4">
                    <h4 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider">Expense Statements List</h4>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                      {expenses.length === 0 ? (
                        <span className="text-xs text-slate-400 block text-center py-12">No expenses logged in this tenant's statement.</span>
                      ) : (
                        expenses.map((e) => (
                          <div key={e.id} className="flex justify-between items-center text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                            <div>
                              <span className="font-extrabold text-slate-700 block text-sm">{e.title}</span>
                              <span className="text-[10px] text-slate-400 block mt-0.5">Category: {e.category} • Date: {e.date}</span>
                            </div>
                            <span className="font-black text-rose-600 text-sm shrink-0">-{formatPriceLocal(e.amount)}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: STAFF MANAGEMENT */}
            {activeTab === "employees" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="employees-tab">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800">Staff & Payroll directories</h3>
                    <p className="text-xs text-slate-400">Oversee active store cashiers, monthly salaries, and attendance records</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Create staff form */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 h-fit">
                    <h4 className="text-sm font-extrabold text-slate-700 mb-4 uppercase tracking-wider">Add Staff Record</h4>
                    <form onSubmit={handleAddEmployee} className="space-y-4 text-xs font-semibold">
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Employee Name *</label>
                        <input type="text" required value={empName} onChange={(e) => setEmpName(e.target.value)} placeholder="e.g. Jack Ryan" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Operational Role</label>
                        <select value={empRole} onChange={(e) => setEmpRole(e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none text-slate-600">
                          <option value="Manager">Store Manager</option>
                          <option value="Cashier">Cashier operator</option>
                          <option value="Stockist">Stockist supervisor</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Monthly Salary *</label>
                        <input type="number" required value={empSalary} onChange={(e) => setEmpSalary(e.target.value)} placeholder="e.g. 2400" className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none" />
                      </div>
                      <button type="submit" className={`w-full ${themeStyles.btn} text-white py-2 rounded-xl font-bold transition-all`}>
                        Create Employee file
                      </button>
                    </form>
                  </div>

                  {/* Lists */}
                  <div className="lg:col-span-2 space-y-4">
                    <h4 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider">Active Staff registries</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {employees.length === 0 ? (
                        <div className="col-span-2 text-center py-12 text-slate-400 text-xs">
                          No staff profile registered. Terminal transactions default to active role modes.
                        </div>
                      ) : (
                        employees.map((emp) => (
                          <div key={emp.id} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center justify-between">
                                <h5 className="font-extrabold text-slate-800 text-sm">{emp.name}</h5>
                                <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 font-bold rounded-lg text-[9px] uppercase">{emp.role}</span>
                              </div>
                              <span className="text-[10px] text-slate-400 block mt-1">Status: Active Service</span>
                            </div>
                            <div className="mt-4 pt-2 border-t border-slate-200 flex items-center justify-between text-xs font-bold">
                              <span className="text-slate-500 font-semibold">Monthly Payroll:</span>
                              <span className="text-slate-800">{formatPriceLocal(Number(emp.salary || 0))}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SETTINGS & SYSTEM CONFIG */}
            {activeTab === "settings" && (
              <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6" id="settings-tab">
                <div className="mb-6 border-b pb-4">
                  <h3 className="text-lg font-extrabold text-slate-800">SaaS Shop Configuration Settings</h3>
                  <p className="text-xs text-slate-400">Modify company metadata, receipts parameters, themes, and network printing configurations</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Theme Selector & Voice parameters */}
                  <div className="space-y-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                      <Palette className="w-4 h-4 text-slate-400" />
                      <span>Visual Presets & Branding</span>
                    </h4>
                    
                    <div>
                      <span className="text-xs text-slate-500 font-bold block mb-2">Workspace Theme</span>
                      <div className="grid grid-cols-2 gap-2">
                        {AVAILABLE_THEMES.map((theme) => (
                          <button
                            key={theme.id}
                            onClick={() => setActiveTheme(theme.id)}
                            className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                              activeTheme === theme.id ? "bg-white border-indigo-400 shadow-sm" : "bg-white hover:bg-slate-100"
                            }`}
                          >
                            <span className={`w-3.5 h-3.5 rounded-full ${theme.primary} shrink-0`} />
                            <span className="text-xs font-semibold text-slate-700 truncate">{theme.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
                      <div>
                        <span className="text-xs text-slate-700 font-bold block">Vocal Alerts (TTS)</span>
                        <span className="text-[10px] text-slate-400 block">Read system warnings aloud</span>
                      </div>
                      <button
                        onClick={() => setEnableVoice(!enableVoice)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold ${enableVoice ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-600"}`}
                      >
                        {enableVoice ? "Active" : "Muted"}
                      </button>
                    </div>
                  </div>

                  {/* Printer Management Dashboard */}
                  <div className="lg:col-span-2 space-y-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div className="flex justify-between items-center mb-2 border-b pb-2">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                        <Printer className="w-4 h-4 text-indigo-500" />
                        <span>Connected Thermal Printer Terminals</span>
                      </h4>
                      <button
                        onClick={handleScanPrintersNetwork}
                        disabled={isScanningPrinters}
                        className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold border border-indigo-200 flex items-center gap-1"
                      >
                        <Radar className="w-3 h-3 text-indigo-600" />
                        <span>{isScanningPrinters ? "Scanning..." : "Scan Ports"}</span>
                      </button>
                    </div>

                    {/* Printer registry addition form */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <input
                        type="text"
                        placeholder="Printer Name (e.g. Kitchen Spool)"
                        value={newPrinterName}
                        onChange={(e) => setNewPrinterName(e.target.value)}
                        className="px-3 py-1.5 bg-white border rounded-xl text-xs focus:outline-none"
                      />
                      <input
                        type="text"
                        placeholder="IP Address (e.g. 192.168.1.150)"
                        value={newPrinterIp}
                        onChange={(e) => setNewPrinterIp(e.target.value)}
                        className="px-3 py-1.5 bg-white border rounded-xl text-xs focus:outline-none"
                      />
                      <button
                        onClick={handleAddPrinterLocal}
                        className="bg-slate-800 hover:bg-slate-900 text-white py-1.5 rounded-xl text-xs font-bold transition-colors"
                      >
                        Add Printer spool
                      </button>
                    </div>

                    {/* Printers logs spool lists */}
                    <div className="space-y-2 mt-4 max-h-[200px] overflow-y-auto">
                      {printers.map((pr) => (
                        <div key={pr.id} className="flex justify-between items-center text-xs bg-white p-3 rounded-xl border border-slate-200">
                          <div>
                            <span className="font-bold text-slate-700 block">{pr.name}</span>
                            <span className="text-[10px] text-slate-400 block">{pr.ip}:{pr.port}</span>
                          </div>
                          <div className="flex gap-2">
                            {pr.isDefault ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold rounded text-[9px] uppercase border border-emerald-100">
                                Primary default
                              </span>
                            ) : (
                              <button
                                onClick={() => handleSetDefaultPrinter(pr.id)}
                                className="text-indigo-600 hover:text-indigo-800 font-bold text-[10px] uppercase"
                              >
                                Set default
                              </button>
                            )}
                            <button
                              onClick={() => handleTestPrinterLocal(pr)}
                              className="text-slate-600 hover:text-slate-800 font-bold text-[10px] uppercase pl-2 border-l"
                            >
                              Test Print
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating interactive scientific calculator button */}
      <div className="fixed bottom-6 right-6 z-40 no-print flex gap-3">
        {/* AI Co-Pilot Floating Toggle Button */}
        <button
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white p-4 rounded-full shadow-2xl hover:scale-105 transition-all flex items-center justify-center relative"
          title="Open AI Co-Pilot"
        >
          <Sparkles className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
          </span>
        </button>

        <button
          onClick={() => setActiveTab(activeTab === "calc" ? "store" : "calc")}
          className={`${themeStyles.primary} text-white p-4 rounded-full shadow-2xl hover:scale-105 transition-all flex items-center justify-center`}
          title="Open Register Calculator"
        >
          <Calculator className="w-6 h-6" />
        </button>
      </div>

      {/* Interactive AI Chatbot Co-Pilot panel */}
      {isChatOpen && (
        <div className="fixed bottom-24 right-6 z-40 max-w-sm w-full h-[480px] bg-white rounded-3xl shadow-2xl border border-slate-200/60 p-4 flex flex-col justify-between no-print animate-in slide-in-from-bottom-5 duration-200">
          {/* Header block */}
          <div className="flex justify-between items-center border-b pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-indigo-100 text-indigo-700 rounded-lg flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800">Chronos AI Co-Pilot</h4>
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">PostgreSQL Connected</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsChatOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages block */}
          <div className="flex-1 overflow-y-auto my-3 space-y-3 pr-1 text-xs">
            {chatMessages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                  msg.role === "user" 
                    ? "bg-indigo-600 text-white rounded-br-none" 
                    : "bg-slate-100 text-slate-700 rounded-bl-none border border-slate-200/30"
                }`}>
                  <p className="whitespace-pre-line">{msg.text}</p>
                </div>
              </div>
            ))}
            {chatLoading && (
              <div className="flex justify-start">
                <div className="p-3 bg-slate-100 text-slate-500 rounded-2xl rounded-bl-none border flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </div>

          {/* Suggested prompts & input footer */}
          <div className="space-y-2 pt-2 border-t">
            {/* Suggestions list */}
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {[
                { label: "Today's sales?", query: "Tell me today's sales and transaction volume" },
                { label: "Low stock items?", query: "Are there any items currently low in stock?" },
                { label: "Best seller?", query: "What is our best-selling product?" }
              ].map((s) => (
                <button
                  key={s.label}
                  type="button"
                  onClick={() => {
                    setChatInput(s.query);
                  }}
                  className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[10px] font-bold rounded-full border border-indigo-100 whitespace-nowrap shrink-0 transition-colors"
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Input field bar */}
            <div className="flex gap-1.5">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSendChatMessage();
                }}
                placeholder="Ask me about sales, stock, forecasting..."
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none"
              />
              <button
                onClick={handleSendChatMessage}
                disabled={chatLoading}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white p-2 rounded-xl text-xs font-bold transition-all shrink-0"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Scientific calculator screen modal fallback */}
      {activeTab === "calc" && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl p-6 border max-w-sm w-full">
            <div className="flex justify-between items-center border-b pb-3 mb-4">
              <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Scientific POS Calculator</span>
              <button onClick={() => setActiveTab("store")} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <ScientificCalculator />
          </div>
        </div>
      )}

      {/* Dynamic Toast notifications hub */}
      <div className="fixed top-6 right-6 z-50 space-y-2 no-print" id="saas-toast-hub">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-4 rounded-2xl shadow-xl border flex items-start gap-3 max-w-sm bg-white/95 backdrop-blur-md transition-all duration-300 transform translate-y-0 ${
              toast.type === "warning" ? "border-rose-100" : toast.type === "success" ? "border-emerald-100" : "border-indigo-100"
            }`}
          >
            <div className={`p-1.5 rounded-lg shrink-0 ${
              toast.type === "warning" ? "bg-rose-50 text-rose-600" : toast.type === "success" ? "bg-emerald-50 text-emerald-600" : "bg-indigo-50 text-indigo-600"
            }`}>
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h5 className="font-bold text-slate-800 text-xs">{toast.title}</h5>
              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">{toast.message}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Dynamic Receipt Drawer modal */}
      <SaaSInvoiceReceipt
        transaction={lastTransaction}
        business={activeBusiness}
        onClose={() => setShowReceipt(false)}
        formatPrice={formatPriceLocal}
        printers={printers}
        onTestPrinter={handleTestPrinterLocal}
      />
    </div>
  );
}
