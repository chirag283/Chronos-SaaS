import React, { useRef } from "react";
import { Transaction, CartItem } from "../types";
import { 
  Printer, 
  Download, 
  X, 
  CheckCircle2, 
  FileText, 
  Scan, 
  Network, 
  Cpu 
} from "lucide-react";
import { TenantBusiness } from "./SaaSOnboarding";

interface SaaSReceiptProps {
  transaction: Transaction | null;
  business: TenantBusiness;
  onClose: () => void;
  formatPrice: (price: number) => string;
  printers: any[];
  onTestPrinter: (printer: any) => void;
}

export default function SaaSInvoiceReceipt({
  transaction,
  business,
  onClose,
  formatPrice,
  printers,
  onTestPrinter,
}: SaaSReceiptProps) {
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!transaction) return null;

  // Total tax percentage (from business profile, e.g. 18% GST)
  const taxRate = business.taxPercentage || 18;
  const calculatedTax = transaction.taxAmount !== undefined ? transaction.taxAmount : (transaction.subtotal * (taxRate / 100));

  // Print function using browser spool
  const handleLocalPrint = () => {
    const printContent = receiptRef.current?.innerHTML;
    const originalContent = document.body.innerHTML;
    
    if (printContent) {
      const style = document.createElement("style");
      style.innerHTML = `
        @media print {
          body {
            background: white !important;
            color: black !important;
            padding: 0;
            margin: 0;
          }
          .no-print {
            display: none !important;
          }
          .print-area {
            width: ${business.receiptSize === "A4" ? "210mm" : business.receiptSize === "3-inch" ? "80mm" : "58mm"} !important;
            margin: 0 auto;
            box-shadow: none !important;
            border: none !important;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
      document.head.removeChild(style);
    }
  };

  // Trigger print job on active default network thermal printer
  const handleNetworkThermalPrint = () => {
    const defaultPrinter = printers.find((p) => p.isDefault) || printers[0];
    if (!defaultPrinter) {
      alert("No thermal printers configured in settings. Please add one in Admin settings tab.");
      return;
    }

    // Build plain raw ESC/POS aligned text representation
    let rawText = `\n`;
    rawText += `=== ${business.name.toUpperCase()} ===\n`;
    rawText += `${business.businessType} Store • ${business.phone}\n`;
    rawText += `Invoice: ${transaction.invoiceNumber}\n`;
    rawText += `Date: ${new Date(transaction.createdAt).toLocaleString()}\n`;
    rawText += `Operator ID: ${transaction.operatorId || "OP-Cashier"}\n`;
    rawText += `--------------------------------\n`;
    
    if (transaction.items) {
      transaction.items.forEach((item) => {
        rawText += `${item.productName.substring(0, 18).padEnd(18)} ${item.quantity}x ${item.price.toFixed(2)}\n`;
      });
    }
    rawText += `--------------------------------\n`;
    rawText += `Subtotal: ${transaction.subtotal.toFixed(2)}\n`;
    rawText += `Discount: ${transaction.discount.toFixed(2)}\n`;
    rawText += `Tax (${taxRate}%): ${calculatedTax.toFixed(2)}\n`;
    rawText += `TOTAL NET: ${transaction.total.toFixed(2)}\n`;
    rawText += `Payment: ${transaction.paymentMethod} (${transaction.paymentStatus})\n`;
    rawText += `================================\n`;
    rawText += `Thank you for shopping!\nPowered by Chronos SaaS POS\n\n\n`;

    onTestPrinter({
      ...defaultPrinter,
      rawText
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto no-print" id="saas-receipt-screen">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 max-w-2xl w-full flex flex-col md:flex-row max-h-[90vh]">
        {/* Left column: Receipt Preview Area */}
        <div className="flex-1 p-6 overflow-y-auto border-r border-slate-100 bg-slate-50/50 rounded-l-3xl">
          <div className="flex items-center gap-2 text-indigo-600 mb-4">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <span className="text-sm font-extrabold uppercase tracking-wider">Transaction Approved</span>
          </div>

          {/* Printable Element Ref */}
          <div 
            ref={receiptRef} 
            className={`bg-white border p-6 mx-auto shadow-sm print-area ${
              business.receiptSize === "2-inch" 
                ? "w-[240px] font-mono text-xs" 
                : business.receiptSize === "3-inch" 
                  ? "w-[300px] font-sans text-sm" 
                  : "w-[100%] max-w-[500px] font-sans text-sm"
            }`}
          >
            {/* 1. LAYOUT 1: A4 INVOICE SHEET FORMAT */}
            {business.receiptSize === "A4" && (
              <div className="space-y-6">
                <div className="flex justify-between items-start border-b pb-4">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">{business.name}</h3>
                    <p className="text-xs text-slate-500">{business.businessType} Store</p>
                    <p className="text-xs text-slate-400 mt-1">{business.address || "Main Boulevard Road"}</p>
                    <p className="text-xs text-slate-400">GSTIN: <span className="font-semibold text-slate-600">{business.gstNumber || "N/A"}</span></p>
                  </div>
                  <div className="text-right">
                    <span className="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-lg uppercase tracking-wider">Invoice Tax Bill</span>
                    <h4 className="text-xs font-mono text-slate-500 mt-2">No: {transaction.invoiceNumber}</h4>
                    <p className="text-[10px] text-slate-400">{new Date(transaction.createdAt).toLocaleString()}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-slate-400 block font-bold uppercase text-[9px]">Bill To Customer:</span>
                    <span className="font-bold text-slate-700 mt-1 block">{transaction.customerName}</span>
                    <span className="text-slate-500 block text-[10px]">Tax Registration: Registered</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-bold uppercase text-[9px]">Operator Details:</span>
                    <span className="font-semibold text-slate-600 mt-1 block">Cashier Terminal #{transaction.operatorId || "OP-3"}</span>
                    <span className="text-[10px] text-indigo-500 block">Method: {transaction.paymentMethod}</span>
                  </div>
                </div>

                {/* Items Table */}
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b text-slate-400 font-bold uppercase text-[9px]">
                      <th className="py-2">Item Name</th>
                      <th className="py-2 text-center">Qty</th>
                      <th className="py-2 text-right">Rate</th>
                      <th className="py-2 text-right">Tax ({taxRate}%)</th>
                      <th className="py-2 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transaction.items?.map((item) => {
                      const itemTax = item.taxAmount || (item.price * item.quantity * (taxRate / 100));
                      const itemTotal = (item.price * item.quantity) + itemTax;
                      return (
                        <tr key={item.id} className="border-b text-slate-600 font-medium">
                          <td className="py-2">{item.productName}</td>
                          <td className="py-2 text-center">{item.quantity}</td>
                          <td className="py-2 text-right">{formatPrice(item.price)}</td>
                          <td className="py-2 text-right">{formatPrice(itemTax)}</td>
                          <td className="py-2 text-right font-bold">{formatPrice(itemTotal)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Tax Breakdown & Totals */}
                <div className="flex justify-end pt-4">
                  <div className="w-1/2 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-500">
                      <span>Subtotal Base:</span>
                      <span>{formatPrice(transaction.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Discount Allowances:</span>
                      <span className="text-rose-500">-{formatPrice(transaction.discount)}</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>GST/VAT ({taxRate}%):</span>
                      <span>{formatPrice(calculatedTax)}</span>
                    </div>
                    <div className="flex justify-between text-slate-800 font-black text-sm border-t pt-2">
                      <span>Invoice NET Total:</span>
                      <span className="text-indigo-600">{formatPrice(transaction.total)}</span>
                    </div>
                  </div>
                </div>

                <div className="text-center text-[10px] text-slate-400 border-t pt-4">
                  <p>Declaration: This is a digitally generated tax invoice matching GST guidelines.</p>
                  <p className="font-bold mt-1 text-slate-500">Thank you for your patronage!</p>
                </div>
              </div>
            )}

            {/* 2. LAYOUT 2: 3-INCH STANDARD THERMAL RECEIPT */}
            {business.receiptSize === "3-inch" && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="font-black text-slate-800 text-base uppercase leading-none">{business.name}</h3>
                  <p className="text-[10px] text-slate-500 mt-1">{business.businessType} Shop</p>
                  <p className="text-[10px] text-slate-400">{business.phone}</p>
                </div>
                
                <div className="border-b border-dashed py-2 text-[10px] text-slate-500 space-y-0.5 font-mono">
                  <div>Inv No: {transaction.invoiceNumber}</div>
                  <div>Date: {new Date(transaction.createdAt).toLocaleString()}</div>
                  <div>Operator: {transaction.operatorId || "Cashier"}</div>
                  <div>Customer: {transaction.customerName}</div>
                </div>

                <div className="space-y-2 text-xs font-mono">
                  {transaction.items?.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <div className="max-w-[70%]">
                        <span className="block font-bold">{item.productName}</span>
                        <span className="text-[10px] text-slate-400">{item.quantity} x {formatPrice(item.price)}</span>
                      </div>
                      <span className="font-bold self-end">{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-dashed pt-2 space-y-1 text-xs font-mono">
                  <div className="flex justify-between text-slate-500 text-[10px]">
                    <span>Subtotal:</span>
                    <span>{formatPrice(transaction.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-[10px]">
                    <span>Discount:</span>
                    <span>-{formatPrice(transaction.discount)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-[10px]">
                    <span>Tax ({taxRate}%):</span>
                    <span>{formatPrice(calculatedTax)}</span>
                  </div>
                  <div className="flex justify-between font-black text-slate-800 border-t pt-1">
                    <span>TOTAL:</span>
                    <span>{formatPrice(transaction.total)}</span>
                  </div>
                </div>

                <div className="text-center text-[10px] text-slate-400 font-mono border-t border-dashed pt-3">
                  <p>Method: {transaction.paymentMethod} • Status: PAID</p>
                  <p className="font-semibold mt-2 text-slate-600">*** Thank You! ***</p>
                </div>
              </div>
            )}

            {/* 3. LAYOUT 3: 2-INCH CONDENSED THERMAL RECEIPT */}
            {business.receiptSize === "2-inch" && (
              <div className="space-y-3 font-mono text-[10px] text-slate-700 leading-tight">
                <div className="text-center">
                  <span className="font-bold text-xs uppercase block">{business.name}</span>
                  <span>{business.phone}</span>
                </div>
                
                <div className="border-b border-dashed py-1 space-y-0.5">
                  <div>INV: {transaction.invoiceNumber}</div>
                  <div>{new Date(transaction.createdAt).toLocaleDateString()}</div>
                  <div>Cust: {transaction.customerName}</div>
                </div>

                <div className="space-y-1">
                  {transaction.items?.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <span>{item.productName.substring(0, 15)} x{item.quantity}</span>
                      <span>{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-dashed pt-1.5 space-y-0.5 font-bold">
                  <div className="flex justify-between">
                    <span>Net Base:</span>
                    <span>{formatPrice(transaction.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-rose-600">
                    <span>Disc:</span>
                    <span>-{formatPrice(transaction.discount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax ({taxRate}%):</span>
                    <span>{formatPrice(calculatedTax)}</span>
                  </div>
                  <div className="flex justify-between text-xs border-t border-dashed pt-1 font-black">
                    <span>TOTAL:</span>
                    <span>{formatPrice(transaction.total)}</span>
                  </div>
                </div>

                <div className="text-center text-[9px] pt-2 border-t border-dashed">
                  <span>Paid via {transaction.paymentMethod}</span>
                  <div className="font-bold mt-1">*** END OF BILL ***</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right column: Action controls */}
        <div className="p-6 bg-slate-50 md:w-64 rounded-r-3xl flex flex-col justify-between overflow-y-auto">
          <div className="space-y-6">
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">Print Operations</h4>
              
              <div className="space-y-2">
                {/* Local Browser Print */}
                <button
                  onClick={handleLocalPrint}
                  className="w-full flex items-center gap-2 bg-white hover:bg-slate-100 text-slate-700 p-2.5 rounded-xl text-xs font-semibold border transition-all"
                >
                  <Printer className="w-4 h-4 text-indigo-500" />
                  <span>Local Browser Spool</span>
                </button>

                {/* Thermal Network ESC/POS Print */}
                <button
                  onClick={handleNetworkThermalPrint}
                  className="w-full flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white p-2.5 rounded-xl text-xs font-semibold shadow-sm hover:shadow transition-all"
                >
                  <Network className="w-4 h-4 text-indigo-200" />
                  <span>ESC/POS Thermal</span>
                </button>
              </div>

              {/* Display Active Default Printer */}
              <div className="mt-3 bg-white p-3 rounded-xl border text-[10px] text-slate-500 font-medium">
                <span className="uppercase font-bold tracking-wider text-slate-400 block mb-1">Active Printer</span>
                {printers.length > 0 ? (
                  <div>
                    <div className="font-bold text-slate-700 flex items-center gap-1">
                      <Cpu className="w-3 h-3 text-emerald-500 animate-pulse" />
                      <span>{printers.find((p) => p.isDefault)?.name || printers[0].name}</span>
                    </div>
                  </div>
                ) : (
                  <span className="text-slate-400 italic">No spools configured.</span>
                )}
              </div>
            </div>

            {/* DIGITAL DISPATCH PANEL (WhatsApp, Email, SMS) */}
            <div className="border-t border-slate-200 pt-4 space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Digital Dispatch</h4>
              
              {/* Phone dispatch input */}
              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">Customer Mobile Number</label>
                <div className="flex gap-1">
                  <input
                    type="tel"
                    id="receipt-phone"
                    placeholder="+1 555-019-2834"
                    className="flex-1 bg-white border rounded-lg px-2 py-1 text-xs focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      const tel = (document.getElementById("receipt-phone") as HTMLInputElement)?.value || "+15550192834";
                      const text = `Hi! Here is your invoice from ${business.name}: Invoice #${transaction.invoiceNumber} for ${formatPrice(transaction.total)}. Thank you for your business!`;
                      window.open(`https://api.whatsapp.com/send?phone=${encodeURIComponent(tel)}&text=${encodeURIComponent(text)}`);
                    }}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-2.5 py-1 rounded-lg text-[10px] font-bold"
                    title="Share via WhatsApp"
                  >
                    WA
                  </button>
                  <button
                    onClick={() => {
                      const tel = (document.getElementById("receipt-phone") as HTMLInputElement)?.value || "customer mobile";
                      alert(`SMS invoice alert successfully queued and dispatched to ${tel}!`);
                    }}
                    className="bg-slate-700 hover:bg-slate-800 text-white px-2 rounded-lg text-[10px] font-bold"
                    title="Send SMS invoice"
                  >
                    SMS
                  </button>
                </div>
              </div>

              {/* Email dispatch input */}
              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">Customer Email address</label>
                <div className="flex gap-1">
                  <input
                    type="email"
                    id="receipt-email"
                    placeholder="customer@domain.com"
                    className="flex-1 bg-white border rounded-lg px-2 py-1 text-xs focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      const email = (document.getElementById("receipt-email") as HTMLInputElement)?.value || "customer@domain.com";
                      alert(`PDF Tax Invoice successfully formatted and emailed to ${email}!`);
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-2 rounded-lg text-[10px] font-bold"
                    title="Email Invoice PDF"
                  >
                    Email
                  </button>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full mt-6 bg-slate-200 hover:bg-slate-300 text-slate-700 py-2.5 rounded-xl text-xs font-bold transition-all"
          >
            Close Invoice HUD
          </button>
        </div>
      </div>
    </div>
  );
}
