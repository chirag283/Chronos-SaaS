import React, { useState, useEffect, useRef } from "react";
import { Play, RotateCcw, HelpCircle, ChevronRight, Check } from "lucide-react";

export default function ScientificCalculator() {
  const [display, setDisplay] = useState<string>("0");
  const [equation, setEquation] = useState<string>("x^2");
  const [calcHistory, setCalcHistory] = useState<string[]>([]);
  const [graphError, setGraphError] = useState<string | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Parse and evaluate scientific expressions
  const evaluateMath = (expr: string, xVal?: number): number => {
    let formatted = expr.toLowerCase();
    
    // Replace mathematical symbols with JS Math equivalents
    // Replacing powers ^ with **
    formatted = formatted.replace(/\^/g, "**");
    // Standard trig and scientific functions
    formatted = formatted.replace(/sin/g, "Math.sin");
    formatted = formatted.replace(/cos/g, "Math.cos");
    formatted = formatted.replace(/tan/g, "Math.tan");
    formatted = formatted.replace(/log/g, "Math.log10");
    formatted = formatted.replace(/ln/g, "Math.log");
    formatted = formatted.replace(/sqrt/g, "Math.sqrt");
    formatted = formatted.replace(/pi/g, "Math.PI");
    formatted = formatted.replace(/e/g, "Math.E");

    if (xVal !== undefined) {
      // Replace independent variable x
      formatted = formatted.replace(/\bx\b/g, `(${xVal})`);
    }

    try {
      // Evaluate expression
      const result = new Function(`return (${formatted})`)();
      if (typeof result !== "number" || isNaN(result) || !isFinite(result)) {
        return NaN;
      }
      return result;
    } catch (e) {
      return NaN;
    }
  };

  // Run a standard calculator evaluation
  const handleCalculate = () => {
    if (display === "0" || !display) return;
    
    const formattedExpr = display
      .replace(/×/g, "*")
      .replace(/÷/g, "/");

    const res = evaluateMath(formattedExpr);
    if (isNaN(res)) {
      setDisplay("Error");
    } else {
      // Format float results elegantly
      const roundedRes = Math.round(res * 1000000) / 1000000;
      setCalcHistory((prev) => [display + " = " + roundedRes, ...prev.slice(0, 4)]);
      setDisplay(roundedRes.toString());
    }
  };

  // Button click handlers
  const handleBtnClick = (val: string) => {
    setDisplay((prev) => {
      if (prev === "0" || prev === "Error") {
        return val;
      }
      return prev + val;
    });
  };

  const handleClear = () => {
    setDisplay("0");
  };

  const handleBackspace = () => {
    setDisplay((prev) => {
      if (prev.length <= 1 || prev === "Error") return "0";
      return prev.slice(0, -1);
    });
  };

  // Graph plotting engine
  const drawGraph = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Setup coordinates: we graph from x = -10 to x = 10
    const xMin = -10;
    const xMax = 10;
    const yMin = -10;
    const yMax = 10;

    // Mapping functions from math coords to pixel coords
    const toPixelX = (x: number) => ((x - xMin) / (xMax - xMin)) * width;
    const toPixelY = (y: number) => height - ((y - yMin) / (yMax - yMin)) * height;

    // Draw Grid Lines
    ctx.strokeStyle = "#e5e7eb"; // neutral-200
    ctx.lineWidth = 0.5;
    ctx.font = "9px monospace";
    ctx.fillStyle = "#9ca3af"; // neutral-400

    // Vertical grid and labels
    for (let x = xMin; x <= xMax; x++) {
      const px = toPixelX(x);
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, height);
      ctx.stroke();

      if (x !== 0) {
        ctx.fillText(x.toString(), px - 5, toPixelY(0) + 12);
      }
    }

    // Horizontal grid and labels
    for (let y = yMin; y <= yMax; y++) {
      const py = toPixelY(y);
      ctx.beginPath();
      ctx.moveTo(0, py);
      ctx.lineTo(width, py);
      ctx.stroke();

      if (y !== 0) {
        ctx.fillText(y.toString(), toPixelX(0) + 5, py + 3);
      }
    }

    // Draw Core Axes (X and Y intersecting)
    ctx.strokeStyle = "#4b5563"; // neutral-600
    ctx.lineWidth = 1.5;
    
    // Y Axis
    ctx.beginPath();
    ctx.moveTo(toPixelX(0), 0);
    ctx.lineTo(toPixelX(0), height);
    ctx.stroke();

    // X Axis
    ctx.beginPath();
    ctx.moveTo(0, toPixelY(0));
    ctx.lineTo(width, toPixelY(0));
    ctx.stroke();

    // Origin label
    ctx.fillText("0", toPixelX(0) - 10, toPixelY(0) + 12);

    // Plot Equation Curve
    ctx.strokeStyle = "#4f46e5"; // indigo-600
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    let started = false;
    let pointsCount = 0;
    let hasNan = false;

    // Evaluate 200 points along X-range
    for (let px = 0; px <= width; px++) {
      // Map pixel px back to math x value
      const x = xMin + (px / width) * (xMax - xMin);
      const y = evaluateMath(equation, x);

      if (!isNaN(y) && isFinite(y)) {
        const py = toPixelY(y);
        if (py >= 0 && py <= height) {
          if (!started) {
            ctx.beginPath();
            ctx.moveTo(px, py);
            started = true;
          } else {
            ctx.lineTo(px, py);
          }
          pointsCount++;
        } else {
          // Point is off-screen, break stroke segment to avoid linear wrap-around spikes
          started = false;
        }
      } else {
        started = false;
        hasNan = true;
      }
    }
    
    ctx.stroke();

    if (pointsCount === 0) {
      setGraphError("Equation returned out-of-range or undefined values.");
    } else {
      setGraphError(null);
    }
  };

  useEffect(() => {
    drawGraph();
  }, [equation]);

  // Handle graph resizing & responsiveness
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas && canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = Math.max(220, canvas.parentElement.clientHeight || 220);
        drawGraph();
      }
    };
    
    window.addEventListener("resize", handleResize);
    // Initial size trigger
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, [equation]);

  return (
    <div className="flex flex-col gap-4 bg-slate-900 text-white rounded-xl p-5 shadow-sm border border-slate-800">
      
      {/* Header */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h3 className="font-display font-semibold text-sm text-slate-100 tracking-tight">Scientific Workspace</h3>
          <p className="font-mono text-[10px] text-slate-400">Complex Calc & Plot Engine</p>
        </div>
        <span className="px-2.5 py-0.5 rounded-full text-[9px] bg-indigo-500/20 text-indigo-400 font-mono border border-indigo-500/30 tracking-wider uppercase">
          Engine Active
        </span>
      </div>

      {/* Screen Display */}
      <div className="bg-slate-950/85 p-3.5 rounded-lg border border-slate-800/80">
        <div className="text-right text-[10px] text-slate-400 font-mono h-4 overflow-hidden select-none">
          {calcHistory.length > 0 ? calcHistory[0] : ""}
        </div>
        <div className="text-right text-xl font-mono text-indigo-400 overflow-x-auto whitespace-nowrap mt-1.5 scrollbar-thin">
          {display}
        </div>
      </div>

      {/* Grid: Scientific & Standard Buttons */}
      <div className="grid grid-cols-5 gap-1.5 font-mono text-xs">
        {/* Scientific row 1 */}
        <button onClick={() => handleBtnClick("sin(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">sin</button>
        <button onClick={() => handleBtnClick("cos(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">cos</button>
        <button onClick={() => handleBtnClick("tan(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">tan</button>
        <button onClick={() => handleBtnClick("log(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">log</button>
        <button onClick={() => handleBtnClick("ln(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">ln</button>

        {/* Scientific row 2 */}
        <button onClick={() => handleBtnClick("^")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">xʸ</button>
        <button onClick={() => handleBtnClick("sqrt(")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">√</button>
        <button onClick={() => handleBtnClick("pi")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">π</button>
        <button onClick={() => handleBtnClick("e")} className="py-2 bg-slate-800/40 hover:bg-slate-800 text-slate-300 rounded transition border border-slate-800">e</button>
        <button onClick={() => handleBtnClick("x")} className="py-2 bg-slate-800/45 hover:bg-slate-850 text-indigo-400 font-bold rounded transition border border-slate-800">x</button>

        {/* Standard Calculator Core Buttons */}
        <button onClick={() => handleBtnClick("(")} className="py-2.5 bg-slate-800 hover:bg-slate-750 text-white rounded transition"> ( </button>
        <button onClick={() => handleBtnClick(")")} className="py-2.5 bg-slate-800 hover:bg-slate-750 text-white rounded transition"> ) </button>
        <button onClick={handleBackspace} className="py-2.5 bg-rose-950/45 text-rose-300 border border-rose-900/40 rounded hover:bg-rose-900/50 transition">Del</button>
        <button onClick={handleClear} className="py-2.5 bg-amber-950/45 text-amber-300 border border-amber-900/40 rounded hover:bg-amber-900/50 transition">AC</button>
        <button onClick={() => handleBtnClick("/")} className="py-2.5 bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 rounded hover:bg-indigo-900/50 transition">÷</button>

        <button onClick={() => handleBtnClick("7")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">7</button>
        <button onClick={() => handleBtnClick("8")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">8</button>
        <button onClick={() => handleBtnClick("9")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">9</button>
        <button onClick={() => handleBtnClick("*")} className="py-2.5 bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 rounded hover:bg-indigo-900/50 transition">×</button>
        <button onClick={() => handleBtnClick("+")} className="py-2.5 row-span-2 bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 rounded hover:bg-indigo-900/50 flex items-center justify-center font-bold text-lg transition">+</button>

        <button onClick={() => handleBtnClick("4")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">4</button>
        <button onClick={() => handleBtnClick("5")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">5</button>
        <button onClick={() => handleBtnClick("6")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">6</button>
        <button onClick={() => handleBtnClick("-")} className="py-2.5 bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 rounded hover:bg-indigo-900/50 font-bold transition">-</button>

        <button onClick={() => handleBtnClick("1")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">1</button>
        <button onClick={() => handleBtnClick("2")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">2</button>
        <button onClick={() => handleBtnClick("3")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">3</button>
        <button onClick={() => handleCalculate()} className="py-2.5 row-span-2 bg-indigo-600 hover:bg-indigo-550 text-white rounded flex items-center justify-center font-bold text-lg border border-indigo-500 shadow-md shadow-indigo-600/10 transition">=</button>
        <button onClick={() => handleBtnClick("0")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition">0</button>

        <button onClick={() => handleBtnClick(".")} className="py-2.5 bg-slate-800/70 hover:bg-slate-700 text-slate-100 rounded transition font-bold">.</button>
        <button onClick={() => handleBtnClick("x")} className="py-2.5 bg-slate-800/75 hover:bg-slate-750 text-indigo-400 font-bold rounded transition">x</button>
        <button onClick={() => setEquation(display)} className="py-2.5 bg-indigo-900/40 hover:bg-indigo-950/50 text-indigo-300 border border-indigo-900/40 rounded flex items-center justify-center gap-1 font-sans transition">
          <Play className="w-3 h-3 fill-indigo-300" /> Plot
        </button>
      </div>

      {/* Graph Section */}
      <div className="flex flex-col gap-2 mt-2 bg-slate-950 rounded-xl p-3.5 border border-slate-800/80">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
            <span className="font-sans text-xs text-slate-300 font-medium">Real-Time Graphing</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] text-indigo-400 bg-indigo-950/80 px-2.5 py-0.5 rounded border border-indigo-900/30">
              y = {equation}
            </span>
            <button
              onClick={() => setEquation("x^2")}
              title="Reset graph equation"
              className="p-1 hover:bg-slate-800 rounded text-slate-400 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Input box to directly edit Graph Equation */}
        <div className="flex gap-2 items-center">
          <span className="font-mono text-xs text-slate-400">y =</span>
          <input
            type="text"
            value={equation}
            onChange={(e) => setEquation(e.target.value)}
            placeholder="e.g. x^2, sin(x), cos(x)"
            className="flex-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Plotting Canvas container */}
        <div className="relative border border-slate-900 bg-white rounded overflow-hidden flex items-center justify-center">
          <canvas ref={canvasRef} className="w-full h-44 block" />
          
          {graphError && (
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-4 text-center">
              <div>
                <p className="text-rose-400 font-sans text-xs font-semibold">Graph Evaluation Error</p>
                <p className="text-slate-400 font-mono text-[10px] mt-1 max-w-xs">{graphError}</p>
                <button
                  onClick={() => setEquation("x^2")}
                  className="mt-2.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-xs rounded text-white font-sans transition"
                >
                  Reset Equation
                </button>
              </div>
            </div>
          )}
        </div>
        
        {/* Math Legend Helper */}
        <div className="text-[9px] text-slate-500 font-mono flex flex-wrap gap-2 pt-1 border-t border-slate-900">
          <span>Usage:</span>
          <span>• <code className="text-slate-400">x^2</code></span>
          <span>• <code className="text-slate-400">sin(x)</code></span>
          <span>• <code className="text-slate-400">cos(x)*3</code></span>
          <span>• <code className="text-slate-400">sqrt(x)</code></span>
          <span>• <code className="text-slate-400">pi</code></span>
        </div>
      </div>
    </div>
  );
}
