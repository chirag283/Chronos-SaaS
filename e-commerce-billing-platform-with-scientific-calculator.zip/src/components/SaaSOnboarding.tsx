import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building2, 
  UserCheck, 
  Settings, 
  ShieldAlert, 
  Plus, 
  Sparkles, 
  Check, 
  ArrowRight, 
  Briefcase,
  Layers,
  MapPin,
  FileSpreadsheet,
  Coins
} from "lucide-react";

export interface TenantBusiness {
  id: number;
  name: string;
  ownerName: string;
  gstNumber?: string;
  phone: string;
  email: string;
  address?: string;
  businessType: string;
  logoUrl?: string | null;
  currency: string;
  language: string;
  timezone: string;
  invoicePrefix: string;
  receiptSize: string;
  taxPercentage: number;
}

interface OnboardingProps {
  activeBusiness: TenantBusiness;
  availableBusinesses: TenantBusiness[];
  activeRole: "super_admin" | "owner" | "manager" | "cashier";
  onSwitchBusiness: (id: number) => void;
  onSwitchRole: (role: "super_admin" | "owner" | "manager" | "cashier") => void;
  onRegisterBusiness: (data: any) => Promise<void>;
  isAdminUnlocked: boolean;
  onUnlockAdmin: (pin: string) => boolean;
}

export default function SaaSOnboarding({
  activeBusiness,
  availableBusinesses,
  activeRole,
  onSwitchBusiness,
  onSwitchRole,
  onRegisterBusiness,
  isAdminUnlocked,
  onUnlockAdmin,
}: OnboardingProps) {
  const [showWizard, setShowWizard] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState(false);

  // Form states for the onboarding wizard
  const [formData, setFormData] = useState({
    name: "",
    ownerName: "",
    gstNumber: "",
    phone: "",
    email: "",
    address: "",
    businessType: "Grocery",
    currency: "USD",
    language: "English",
    timezone: "UTC",
    invoicePrefix: "INV",
    receiptSize: "3-inch",
    taxPercentage: 18,
  });

  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onRegisterBusiness(formData);
      setShowWizard(false);
      // Reset form
      setFormData({
        name: "",
        ownerName: "",
        gstNumber: "",
        phone: "",
        email: "",
        address: "",
        businessType: "Grocery",
        currency: "USD",
        language: "English",
        timezone: "UTC",
        invoicePrefix: "INV",
        receiptSize: "3-inch",
        taxPercentage: 18,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = onUnlockAdmin(pinInput);
    if (success) {
      setPinError(false);
      setPinInput("");
    } else {
      setPinError(true);
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-md rounded-2xl border border-slate-100 p-6 shadow-sm mb-6" id="saas-onboarding-container">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        {/* Left Side: Active Business Profile */}
        <div className="flex items-start gap-4">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Building2 className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-bold text-slate-800 tracking-tight">{activeBusiness.name}</h2>
              <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-full border border-indigo-100">
                {activeBusiness.businessType}
              </span>
              <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-full border border-emerald-100 uppercase">
                {activeBusiness.currency}
              </span>
            </div>
            <p className="text-sm text-slate-500 mt-1">
              Registered Owner: <span className="font-semibold text-slate-700">{activeBusiness.ownerName}</span> • Tax Rate:{" "}
              <span className="font-semibold text-slate-700">{activeBusiness.taxPercentage}%</span>
            </p>
            <div className="flex gap-4 mt-2 text-xs text-slate-400">
              <span>Prefix: <span className="font-medium text-slate-500">{activeBusiness.invoicePrefix}</span></span>
              <span>Printer: <span className="font-medium text-slate-500">{activeBusiness.receiptSize}</span></span>
              <span>GST/VAT: <span className="font-medium text-slate-500">{activeBusiness.gstNumber || "N/A"}</span></span>
            </div>
          </div>
        </div>

        {/* Right Side: Quick Action HUD */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Business Swapper */}
          <div className="flex flex-col">
            <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-1">Active Tenant</label>
            <select
              value={activeBusiness.id}
              onChange={(e) => onSwitchBusiness(Number(e.target.value))}
              className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-sm font-medium rounded-lg border border-slate-200 focus:outline-none transition-colors"
            >
              {availableBusinesses.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.businessType})
                </option>
              ))}
            </select>
          </div>

          {/* Role Swapper (RBAC Simulator) */}
          <div className="flex flex-col">
            <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-1">RBAC Simulator</label>
            <select
              value={activeRole}
              onChange={(e) => onSwitchRole(e.target.value as any)}
              className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-sm font-semibold rounded-lg border border-amber-200 focus:outline-none transition-colors"
            >
              <option value="owner">Shop Owner (Full Admin)</option>
              <option value="manager">Manager (Stock & Customers)</option>
              <option value="cashier">Cashier (POS Only)</option>
              <option value="super_admin">Global Super Admin</option>
            </select>
          </div>

          {/* Onboarding Wizard Trigger */}
          <button
            onClick={() => setShowWizard(true)}
            className="mt-4 sm:mt-0 flex items-center gap-1.5 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white px-4 py-2 text-sm font-semibold rounded-xl shadow-sm hover:shadow transition-all"
            id="wizard-trigger-btn"
          >
            <Plus className="w-4 h-4" />
            <span>Onboard Shop</span>
          </button>
        </div>
      </div>

      {/* Role Warnings Info-Bar */}
      {activeRole === "cashier" && (
        <div className="mt-4 p-2.5 bg-rose-50 text-rose-800 rounded-lg flex items-center gap-2 text-xs border border-rose-100">
          <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0" />
          <span>
            <strong>Cashier Mode Enabled:</strong> Administrative functions, settings, financial graphs, and supplier sheets are restricted. Only POS Billing is accessible.
          </span>
        </div>
      )}

      {activeRole === "manager" && (
        <div className="mt-4 p-2.5 bg-yellow-50 text-yellow-800 rounded-lg flex items-center gap-2 text-xs border border-yellow-100">
          <ShieldAlert className="w-4 h-4 text-yellow-600 shrink-0" />
          <span>
            <strong>Manager Mode Enabled:</strong> You have permission to edit stock levels, view suppliers, and manage customers. Store configuration settings remain locked.
          </span>
        </div>
      )}

      {/* Onboarding Wizard Modal */}
      <AnimatePresence>
        {showWizard && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl shadow-xl border border-slate-100 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              id="onboarding-wizard-modal"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/80 rounded-t-3xl">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-lg font-extrabold text-slate-800">SaaS Onboarding: Register New Business</h3>
                </div>
                <button
                  onClick={() => setShowWizard(false)}
                  className="p-1.5 hover:bg-slate-200 text-slate-500 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                {/* Section 1: Business Identity */}
                <div>
                  <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                    <Briefcase className="w-3.5 h-3.5" />
                    <span>Business Identity</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Business Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Apex Supermarket"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Business Type</label>
                      <select
                        value={formData.businessType}
                        onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700"
                      >
                        <option value="Grocery">Grocery / Supermarket</option>
                        <option value="Fashion">Clothing / Fashion</option>
                        <option value="Electronics">Electronics / Tech Store</option>
                        <option value="Pharmacy">Pharmacy / Healthcare</option>
                        <option value="Restaurant">Restaurant / Bistro</option>
                        <option value="Wholesale">Wholesale / Warehouse</option>
                        <option value="Retail">Retail Shop</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section 2: Contact & Admin */}
                <div>
                  <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5 mb-3 mt-1">
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Onboarding Contact Profile</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Owner Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.ownerName}
                        onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                        placeholder="e.g. Alexander Pierce"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">GST/VAT Number (Optional)</label>
                      <input
                        type="text"
                        value={formData.gstNumber}
                        onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })}
                        placeholder="e.g. 27AAAAA1111A1Z1"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Contact Phone *</label>
                      <input
                        type="text"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="e.g. +1 555-0199"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Contact Email *</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. info@apexmarket.com"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                  <div className="mt-3">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Business Address</label>
                    <textarea
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="e.g. 104 Commerce St, Suite B"
                      rows={2}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {/* Section 3: Billing Specifications */}
                <div>
                  <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5 mb-3 mt-1">
                    <Settings className="w-3.5 h-3.5" />
                    <span>Billing & Local Specifications</span>
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Currency</label>
                      <select
                        value={formData.currency}
                        onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                      >
                        <option value="USD">USD ($)</option>
                        <option value="EUR">EUR (€)</option>
                        <option value="GBP">GBP (£)</option>
                        <option value="JPY">JPY (¥)</option>
                        <option value="INR">INR (₹)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Invoice Prefix</label>
                      <input
                        type="text"
                        value={formData.invoicePrefix}
                        onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Tax (%)</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={formData.taxPercentage}
                        onChange={(e) => setFormData({ ...formData, taxPercentage: Number(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Receipt Format</label>
                      <select
                        value={formData.receiptSize}
                        onChange={(e) => setFormData({ ...formData, receiptSize: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none text-slate-700"
                      >
                        <option value="2-inch">2-inch Thermal</option>
                        <option value="3-inch">3-inch Thermal</option>
                        <option value="A4">Standard A4 Sheet</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowWizard(false)}
                    className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white px-5 py-2 text-sm font-semibold rounded-xl shadow-sm transition-all"
                  >
                    {loading ? (
                      <span>Onboarding...</span>
                    ) : (
                      <>
                        <span>Finish Setup</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// X inline icon fallback to avoid imports issues
function X({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
    </svg>
  );
}
