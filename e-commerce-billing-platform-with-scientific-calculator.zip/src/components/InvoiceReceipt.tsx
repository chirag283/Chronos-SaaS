import React, { useState, useEffect } from "react";
import { Transaction } from "../types";
import { motion } from "motion/react";
import { 
  CheckCircle, 
  Printer, 
  Share2, 
  Download, 
  Sparkles, 
  Calendar, 
  User, 
  CreditCard, 
  DollarSign, 
  Smartphone, 
  ArrowRight,
  ShieldCheck,
  Award,
  Volume2
} from "lucide-react";
import QRCode from "qrcode";

const LOCALIZED_SPEECH = {
  en: {
    lang: "en-US",
    label: "English",
    flag: "🇺🇸",
    text: (name: string, total: string) => `Thank you, ${name}, for your purchase of ${total} dollars. Next customer, please!`,
  },
  es: {
    lang: "es-ES",
    label: "Español",
    flag: "🇪🇸",
    text: (name: string, total: string) => `¡Muchas gracias, ${name}, por su compra de ${total} dólares! ¡Siguiente cliente, por favor!`,
  },
  fr: {
    lang: "fr-FR",
    label: "Français",
    flag: "🇫🇷",
    text: (name: string, total: string) => `Merci beaucoup, ${name}, pour votre achat de ${total} dollars. Client suivant, s'il vous plaît !`,
  },
  de: {
    lang: "de-DE",
    label: "Deutsch",
    flag: "🇩🇪",
    text: (name: string, total: string) => `Vielen Dank, ${name}, für Ihren Einkauf über ${total} Dollar. Der nächste Kunde bitte!`,
  },
  ja: {
    lang: "ja-JP",
    label: "日本語",
    flag: "🇯🇵",
    text: (name: string, total: string) => `ご購入いただきありがとうございます、${name}様。合計金額は${total}ドルです। 次のお客様どうぞ！`,
  },
  hi: {
    lang: "hi-IN",
    label: "हिन्दी",
    flag: "🇮🇳",
    text: (name: string, total: string) => `धन्यवाद ${name}, आपकी ${total} डॉलर की खरीदारी के लिए। कृपया अगले ग्राहक आएँ!`,
  }
};

interface InvoiceReceiptProps {
  transaction: Transaction;
  onClose: () => void;
  isRegisteredUser?: boolean;
  enableVoice?: boolean;
  currency?: string;
  rates?: Record<string, number>;
  printers?: { id: string; name: string; ip: string; port: number; isDefault: boolean; status: string }[];
}

const LOCALIZED_CURRENCY_NAMES: Record<string, Record<string, string>> = {
  USD: { en: "dollars", es: "dólares", fr: "dollars", de: "Dollar", ja: "ドル", hi: "डॉलर" },
  EUR: { en: "euros", es: "euros", fr: "euros", de: "Euro", ja: "ユーロ", hi: "यूरो" },
  GBP: { en: "pounds", es: "libras", fr: "livres", de: "Pfund", ja: "ポンド", hi: "पाउंड" },
  JPY: { en: "yen", es: "yenes", fr: "yen", de: "Yen", ja: "円", hi: "येन" },
  INR: { en: "rupees", es: "rupias", fr: "roupies", de: "Rupien", ja: "ルピー", hi: "रुपये" },
};

const CURRENCIES = [
  { code: "USD", symbol: "$", label: "USD" },
  { code: "EUR", symbol: "€", label: "EUR" },
  { code: "GBP", symbol: "£", label: "GBP" },
  { code: "JPY", symbol: "¥", label: "JPY" },
  { code: "INR", symbol: "₹", label: "INR" },
];

export default function InvoiceReceipt({ 
  transaction, 
  onClose, 
  isRegisteredUser = false, 
  enableVoice = true,
  currency = "USD",
  rates = { USD: 1 },
  printers
}: InvoiceReceiptProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>(" ");
  const [copied, setCopied] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(8);
  const [autoLoop, setAutoLoop] = useState<boolean>(true);

  // Load configured network printers (either passed as prop, or fetched from localStorage)
  const [printersList, setPrintersList] = useState<any[]>(() => {
    if (printers && printers.length > 0) return printers;
    try {
      const saved = localStorage.getItem("chronos_printers");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "p1", name: "Local Virtual Printer", ip: "127.0.0.1", port: 9100, isDefault: true, status: "UNKNOWN" }
    ];
  });

  const [selectedPrinterId, setSelectedPrinterId] = useState<string>("");
  const [isPrintingNetwork, setIsPrintingNetwork] = useState<boolean>(false);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  useEffect(() => {
    if (printers && printers.length > 0) {
      setPrintersList(printers);
    }
  }, [printers]);

  useEffect(() => {
    const defaultP = printersList.find((p) => p.isDefault);
    if (defaultP) {
      setSelectedPrinterId(defaultP.id);
    } else if (printersList.length > 0) {
      setSelectedPrinterId(printersList[0].id);
    }
  }, [printersList]);

  const handleNetworkPrint = async () => {
    const printer = printersList.find((p) => p.id === selectedPrinterId);
    if (!printer) {
      alert("Please select a network printer first.");
      return;
    }

    setIsPrintingNetwork(true);
    setPrintStatus("Sending print job...");
    try {
      const sym = CURRENCIES.find((c) => c.code === currency)?.symbol || "$";
      const rate = rates[currency] || 1;
      
      let itemsText = "";
      transaction.items?.forEach((item) => {
        const itemLine = `${item.productName} x${item.quantity}`;
        const priceLine = `${sym}${(item.price * rate).toFixed(2)}`;
        const padCount = Math.max(1, 32 - itemLine.length - priceLine.length);
        itemsText += `${itemLine}${" ".repeat(padCount)}${priceLine}\n`;
      });

      const receiptText = `
RECEIPT NO: #000${transaction.id}
DATE: ${new Date(transaction.createdAt).toLocaleString()}
OPERATOR ID: ${transaction.operatorId || "Cashier"}
CUSTOMER: ${transaction.customerName || "Walk-In"}
--------------------------------
${itemsText}
--------------------------------
SUBTOTAL:             ${formatPrice(transaction.subtotal)}
DISCOUNT:            -${formatPrice(transaction.discount)}
TOTAL PAID:           ${formatPrice(transaction.total)}
--------------------------------
Payment Method:       ${transaction.paymentMethod}
POSTGRES SALES REGISTRY SECURE SYNC
Thank you for your business!
`;

      const res = await fetch("/api/printer/print", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ip: printer.ip,
          port: printer.port,
          transaction,
          rawText: receiptText,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setPrintStatus("Printed successfully!");
          setTimeout(() => setPrintStatus(null), 3000);
        } else {
          setPrintStatus(`Failed: ${data.error}`);
        }
      } else {
        const data = await res.json();
        setPrintStatus(`Failed: ${data.error || "Printer offline"}`);
      }
    } catch (err: any) {
      setPrintStatus(`Error: ${err.message}`);
    } finally {
      setIsPrintingNetwork(false);
    }
  };

  const getBrowserLanguage = (): string => {
    try {
      const navLang = navigator.language.split("-")[0];
      return (navLang in LOCALIZED_SPEECH) ? navLang : "en";
    } catch {
      return "en";
    }
  };

  const [selectedLang, setSelectedLang] = useState<string>(getBrowserLanguage());

  const formatPrice = (priceInUsd: number) => {
    const rate = rates[currency] || 1;
    const converted = priceInUsd * rate;
    const currentSymbol = CURRENCIES.find(c => c.code === currency)?.symbol || "$";
    
    if (currency === "JPY") {
      return `${currentSymbol}${Math.round(converted).toLocaleString()}`;
    }
    return `${currentSymbol}${converted.toFixed(2)}`;
  };

  useEffect(() => {
    if (!autoLoop) return;
    if (countdown <= 0) {
      onClose();
      return;
    }
    const interval = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [countdown, autoLoop, onClose]);

  const speakInvoiceText = () => {
    try {
      if (!enableVoice) {
        console.log("Speech synthesis muted via parent voice controller.");
        return;
      }
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const cleanName = transaction.customerName && transaction.customerName !== "Guest Customer" ? transaction.customerName : "valued customer";
        const currentLang = selectedLang in LOCALIZED_SPEECH ? selectedLang : "en";
        const langConfig = LOCALIZED_SPEECH[currentLang as keyof typeof LOCALIZED_SPEECH] || LOCALIZED_SPEECH.en;
        
        const convertedTotal = transaction.total * (rates[currency] || 1);
        const currencyWord = LOCALIZED_CURRENCY_NAMES[currency]?.[currentLang] || LOCALIZED_CURRENCY_NAMES.USD[currentLang];
        const totalValStr = currency === "JPY" 
          ? `${Math.round(convertedTotal)}`
          : `${convertedTotal.toFixed(2)}`;

        let speechText = langConfig.text(cleanName, totalValStr);
        speechText = speechText
          .replace("dollars", currencyWord)
          .replace("dólares", currencyWord)
          .replace("dollars", currencyWord) // double replace for safety
          .replace("Dollar", currencyWord)
          .replace("ドル", currencyWord)
          .replace("डॉलर", currencyWord);

        const utterance = new SpeechSynthesisUtterance(speechText);
        utterance.lang = langConfig.lang;
        
        const voices = window.speechSynthesis.getVoices();
        const voice = voices.find(v => v.lang.startsWith(langConfig.lang) && (v.name.includes("Google") || v.name.includes("Natural"))) || 
                      voices.find(v => v.lang.startsWith(langConfig.lang)) ||
                      voices.find(v => v.lang.startsWith(langConfig.lang.split("-")[0]));
        if (voice) {
          utterance.voice = voice;
        }
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
      }
    } catch (err) {
      console.error("Speech Synthesis error:", err);
    }
  };

  useEffect(() => {
    if (transaction) {
      const t = setTimeout(() => {
        speakInvoiceText();
      }, 400);
      return () => clearTimeout(t);
    }
  }, [transaction, selectedLang]);

  // Generate dynamic QR code data URL representing transaction details
  useEffect(() => {
    if (transaction) {
      const payloadString = JSON.stringify({
        txnId: transaction.id,
        name: transaction.customerName,
        total: transaction.total,
        method: transaction.paymentMethod,
        date: transaction.createdAt,
        verifyUrl: `https://chronos-ledger.cloud/verify/${transaction.id}`
      });

      QRCode.toDataURL(payloadString, {
        margin: 1,
        width: 300,
        color: {
          dark: "#0f172a", // slate-900
          light: "#ffffff" // white
        }
      })
        .then((url) => setQrCodeUrl(url))
        .catch((err) => console.error("Error generating QR Code:", err));
    }
  }, [transaction]);

  // Handle share/copy action
  const handleCopyLink = () => {
    const convertedTotal = transaction.total * (rates[currency] || 1);
    const sym = CURRENCIES.find(c => c.code === currency)?.symbol || "$";
    const totalValStr = currency === "JPY" ? Math.round(convertedTotal).toLocaleString() : convertedTotal.toFixed(2);
    const text = `Chronos Receipt #${transaction.id} for ${transaction.customerName} - Total ${sym}${totalValStr}`;
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Generate personalized greeting based on categories in transaction
  const getPersonalizedMessage = () => {
    const name = transaction.customerName || "Valued Customer";
    const total = transaction.total;

    // Detect purchased categories if items are attached
    const items = transaction.items || [];
    const hasAccessories = items.some(it => 
      it.productName.toLowerCase().includes("wallet") || 
      it.productName.toLowerCase().includes("watch") ||
      it.productName.toLowerCase().includes("accessories")
    );
    const hasEssentials = items.some(it => 
      it.productName.toLowerCase().includes("milk") || 
      it.productName.toLowerCase().includes("bread") ||
      it.productName.toLowerCase().includes("eggs")
    );

    // Determine Loyalty Points Earned (e.g. 1 point per $10 spent)
    const pointsEarned = Math.floor(total / 10);

    return (
      <div className="flex flex-col gap-2 bg-indigo-50/50 border border-indigo-100 rounded-xl p-4 mt-2">
        <div className="flex items-center gap-2 text-indigo-800 font-medium text-xs">
          <Award className="w-4 h-4 text-indigo-600 animate-pulse" />
          <span>Loyalty & Appreciation Card</span>
        </div>
        
        <p className="text-[11px] text-slate-600 leading-relaxed">
          Hello <span className="font-semibold text-slate-900">{name}</span>, thank you so much for your support! 
          {isRegisteredUser ? (
            <>
              {" "}As a signed-in Chronos loyalty member, you've earned <span className="font-bold text-indigo-700">{pointsEarned} ledger tokens</span> from this checkout. Your secure database balance has been updated automatically.
            </>
          ) : (
            <>
              {" "}We appreciate your trust. Sign in with Google on your next visit to log your transactions directly and start earning points!
            </>
          )}
        </p>

        {/* Category specific messaging */}
        {hasAccessories && (
          <p className="text-[10px] text-slate-500 italic mt-0.5">
            💡 Style Note: Rock those new premium accessories with confidence! ✨
          </p>
        )}
        {hasEssentials && (
          <p className="text-[10px] text-slate-500 italic mt-0.5">
            💡 Freshness Guarantee: All grocery items are securely packed and ready for consumption. 🍳
          </p>
        )}
      </div>
    );
  };

  const paymentIcons: Record<string, React.ReactNode> = {
    Card: <CreditCard className="w-3.5 h-3.5 text-slate-500" />,
    UPI: <Smartphone className="w-3.5 h-3.5 text-slate-500" />,
    Cash: <DollarSign className="w-3.5 h-3.5 text-slate-500" />
  };

  // Motion variants for staggered line item reveal
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -10 },
    show: { opacity: 1, x: 0 }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <style>{`
        @page {
          size: auto;
          margin: 0mm;
        }
        @media print {
          /* Hide standard screen layout including overlays and frames */
          body * {
            visibility: hidden !important;
          }
          /* Show ONLY the specific receipt frame and its components */
          #invoice-receipt-component, #invoice-receipt-component * {
            visibility: visible !important;
          }
          /* Hide all interactive widgets, language pickers, auto-loops, and buttons */
          .no-print, .no-print * {
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
          }
          /* Format for thermal receipt dimensions */
          body, html, #root {
            background: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          .fixed, .backdrop-blur-xs {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            height: auto !important;
            background: transparent !important;
            backdrop-filter: none !important;
            display: block !important;
            z-index: auto !important;
          }
          #invoice-receipt-component {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 80mm !important; /* Standard thermal receipt printer roll size */
            max-width: 100% !important;
            margin: 0 !important;
            padding: 4mm 2mm !important;
            border: none !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            background: #ffffff !important;
            color: #000000 !important;
            display: flex !important;
            flex-direction: column !important;
          }
          /* Expand the scrollable list of products fully for print output */
          #invoice-receipt-component .overflow-y-auto {
            max-height: none !important;
            height: auto !important;
            overflow: visible !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          /* Protect thermal heads from overheating (replace solid dark backgrounds with clean borders) */
          #invoice-receipt-component .bg-slate-900 {
            background: #ffffff !important;
            color: #000000 !important;
            border-bottom: 2px dashed #000000 !important;
            padding-top: 6px !important;
            padding-bottom: 12px !important;
          }
          #invoice-receipt-component .text-white,
          #invoice-receipt-component .text-slate-100,
          #invoice-receipt-component .text-slate-400 {
            color: #000000 !important;
          }
          #invoice-receipt-component .bg-emerald-500\\/10 {
            background: transparent !important;
            border: 1px solid #000000 !important;
            color: #000000 !important;
          }
          #invoice-receipt-component .text-emerald-400 {
            color: #000000 !important;
          }
          /* Ensure other high-contrast grayscale renderings */
          #invoice-receipt-component img {
            filter: grayscale(100%) !important;
            contrast: 140% !important;
          }
          /* Force standard colors to pure print-friendly shades */
          #invoice-receipt-component .bg-slate-50\\/35,
          #invoice-receipt-component .bg-slate-50,
          #invoice-receipt-component .bg-white {
            background: #ffffff !important;
            color: #000000 !important;
          }
          #invoice-receipt-component .text-slate-900,
          #invoice-receipt-component .text-slate-800,
          #invoice-receipt-component .text-slate-700,
          #invoice-receipt-component .text-slate-600,
          #invoice-receipt-component .text-slate-500 {
            color: #000000 !important;
          }
          #invoice-receipt-component .border-slate-200,
          #invoice-receipt-component .border-slate-150,
          #invoice-receipt-component .border-slate-100,
          #invoice-receipt-component .border-gray-100 {
            border-color: #000000 !important;
            border-style: dashed !important;
          }
        }
      `}</style>

      {/* Outer container animating the overall scale & rotation on entry */}
      <motion.div
        initial={{ scale: 0.9, y: 30, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.9, y: 30, opacity: 0 }}
        transition={{ type: "spring", duration: 0.5, bounce: 0.2 }}
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full flex flex-col overflow-hidden my-8"
        id="invoice-receipt-component"
      >
        {/* Receipt Header Banner */}
        <div className="bg-slate-900 p-6 text-center text-white flex flex-col gap-1 items-center justify-center relative">
          <div className="absolute top-4 right-4 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" /> SECURE SQL
          </div>

          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="bg-emerald-500/10 p-2.5 rounded-full border border-emerald-500/30 shrink-0 mt-2"
          >
            <CheckCircle className="w-6 h-6 text-emerald-400" />
          </motion.div>
          
          <h3 className="font-display font-bold text-base tracking-widest mt-3 text-slate-100">TRANSACTION APPROVED</h3>
          <p className="text-[10px] font-mono uppercase tracking-widest text-slate-400">PostgreSQL Registry Synced</p>
        </div>

        {/* Physical Paper Scroll Body */}
        <div className="p-6 bg-slate-50/35 flex flex-col gap-5 border-b border-gray-100 flex-1 relative max-h-[70vh] overflow-y-auto scrollbar-thin">
          
          {/* Jagged paper cut effect simulation using SVG triangles */}
          <div className="absolute top-0 left-0 right-0 h-2 flex overflow-hidden">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="w-4 h-2 bg-white flex-shrink-0" style={{ clipPath: "polygon(50% 100%, 0 0, 100% 0)" }} />
            ))}
          </div>

          {/* Chronos Brand Block */}
          <div className="text-center pb-3 border-b border-dashed border-slate-200 mt-2">
            <motion.h4
              initial={{ letterSpacing: "1px" }}
              animate={{ letterSpacing: "2px" }}
              transition={{ repeat: Infinity, duration: 3, repeatType: "reverse" }}
              className="font-display font-bold text-sm text-slate-900 tracking-wider uppercase flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> CHRONOS RETAIL <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            </motion.h4>
            <p className="text-[9px] text-slate-400 font-mono mt-0.5">REGISTER TERMINAL ID: #101-ASIA</p>
          </div>

          {/* Transaction Metadata Grid */}
          <div className="grid grid-cols-2 gap-y-2 gap-x-4 font-mono text-[10px] text-slate-500 bg-white border border-slate-100 rounded-xl p-3.5">
            <div className="flex flex-col gap-0.5">
              <span className="text-slate-400 text-[9px] uppercase">Transaction Number</span>
              <span className="font-bold text-slate-800">#000{transaction.id}</span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-slate-400 text-[9px] uppercase">Billed Customer</span>
              <span className="font-bold text-slate-800 truncate" title={transaction.customerName}>
                {transaction.customerName}
              </span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-slate-400 text-[9px] uppercase">Payment Mode / Status</span>
              <span className="font-bold text-slate-800 flex items-center gap-1">
                {paymentIcons[transaction.paymentMethod] || <CreditCard className="w-3 h-3" />}
                {transaction.paymentMethod} / {transaction.paymentStatus}
              </span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-slate-400 text-[9px] uppercase">Timestamp</span>
              <span className="font-bold text-slate-800">
                {new Date(transaction.createdAt).toLocaleDateString()} {new Date(transaction.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          {/* Itemized Invoice Line Items */}
          <div className="flex flex-col gap-2.5">
            <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider font-bold">Line Items Checklist</span>
            
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              animate="show"
              className="flex flex-col gap-2 bg-white rounded-xl p-3 border border-slate-100"
            >
              {transaction.items?.map((item) => (
                <motion.div 
                  variants={itemVariants}
                  key={item.id} 
                  className="flex justify-between items-start text-slate-600 font-mono text-[11px]"
                >
                  <div className="flex-1 pr-4">
                    <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div>
                      {item.productName}
                    </div>
                    <div className="text-[9px] text-slate-400 ml-3">
                      {item.quantity} units @ {formatPrice(item.price)}
                    </div>
                  </div>
                  <span className="font-bold text-slate-800 shrink-0">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Price Calculations */}
          <div className="flex flex-col gap-2 font-mono text-[11px] bg-slate-100/50 rounded-xl p-3 border border-slate-150">
            <div className="flex justify-between text-slate-500">
              <span>SUBTOTAL:</span>
              <span>{formatPrice(transaction.subtotal)}</span>
            </div>
            {transaction.discount > 0 && (
              <div className="flex justify-between text-indigo-600 font-semibold">
                <span>DISCOUNT APPLIED:</span>
                <span>-{formatPrice(transaction.discount)}</span>
              </div>
            )}
            <div className="flex justify-between text-slate-900 font-extrabold text-xs pt-1.5 border-t border-slate-200">
              <span>TOTAL PAID BILL:</span>
              <span>{formatPrice(transaction.total)}</span>
            </div>
          </div>

          {/* Personalized Greeting Message Card */}
          {getPersonalizedMessage()}

          {/* Dynamic Invoice QR Code Area */}
          <div className="bg-white border border-slate-150 rounded-xl p-4 flex flex-col items-center justify-center gap-3 shadow-xs">
            <span className="font-mono text-[9px] text-slate-400 uppercase tracking-widest font-bold">Digital Receipt Verification</span>
            
            <div className="relative p-2.5 bg-slate-50 rounded-xl border border-slate-200">
              {qrCodeUrl ? (
                <motion.img 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 }}
                  src={qrCodeUrl} 
                  alt="Transaction QR Verification" 
                  className="w-32 h-32 select-none"
                />
              ) : (
                <div className="w-32 h-32 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            
            <p className="font-mono text-[8px] text-slate-400 text-center uppercase tracking-wider leading-relaxed">
              Scan this dynamic QR code to securely verify<br />
              this invoice in the PostgreSQL sales ledger.
            </p>
          </div>

          {/* Localized Audio Announcement Setup */}
          <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 flex flex-col gap-2 mt-1 shadow-2xs no-print">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9px] text-slate-500 uppercase tracking-wider font-bold flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 text-indigo-500" /> Localized Announcement Voice
              </span>
              <span className="text-[8px] font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded font-extrabold uppercase">
                {LOCALIZED_SPEECH[selectedLang as keyof typeof LOCALIZED_SPEECH]?.label || "English"}
              </span>
            </div>
            
            <p className="text-[9px] text-slate-400 font-sans leading-normal">
              Choose an announcement language to play a customized audio thank-you message after the transaction is written to the ledger.
            </p>

            <div className="grid grid-cols-6 gap-1 mt-1">
              {Object.entries(LOCALIZED_SPEECH).map(([key, value]) => (
                <button
                  key={key}
                  onClick={() => setSelectedLang(key)}
                  className={`flex flex-col items-center justify-center py-1.5 rounded border transition-all text-sm relative ${
                    selectedLang === key
                      ? "bg-indigo-600 border-indigo-600 text-white font-bold scale-[1.04] shadow-xs"
                      : "bg-white border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50"
                  }`}
                  title={value.label}
                >
                  <span className="text-base leading-none mb-0.5">{value.flag}</span>
                  <span className="text-[8px] uppercase font-mono tracking-tighter opacity-80">{key}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Network Thermal Printer Integration Area */}
          <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 flex flex-col gap-2.5 mt-1 shadow-2xs no-print">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9px] text-slate-500 uppercase tracking-wider font-bold flex items-center gap-1">
                <Printer className="w-3.5 h-3.5 text-indigo-500" /> Network Thermal Printing
              </span>
              <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded font-extrabold uppercase border ${
                printersList.length > 0
                  ? "text-emerald-600 bg-emerald-50 border-emerald-100"
                  : "text-amber-600 bg-amber-50 border-amber-100"
              }`}>
                {printersList.length > 0 ? `${printersList.length} Configured` : "Not Configured"}
              </span>
            </div>

            {printersList.length > 0 ? (
              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  <select
                    value={selectedPrinterId}
                    onChange={(e) => setSelectedPrinterId(e.target.value)}
                    className="flex-1 bg-white border border-slate-250 rounded-lg px-2.5 py-1 text-[11px] font-sans focus:outline-none focus:border-indigo-500 min-h-[36px]"
                  >
                    {printersList.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.ip}:{p.port})
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleNetworkPrint}
                    disabled={isPrintingNetwork}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-300 text-white rounded-lg text-[10px] font-bold font-mono transition flex items-center justify-center gap-1.5 min-h-[36px] min-w-[90px]"
                  >
                    {isPrintingNetwork ? (
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : "Send Print Job"}
                  </button>
                </div>
                {printStatus && (
                  <p className="text-[9px] font-mono text-center font-bold text-indigo-600 bg-indigo-50/50 border border-indigo-100 py-1 rounded">
                    {printStatus}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-[9px] text-slate-400 font-sans leading-relaxed">
                No network thermal printers registered yet. Go to the <strong className="text-slate-600 font-bold font-mono">Admin Settings (PIN 1234)</strong> to add, auto-detect, and map thermal printers.
              </p>
            )}
          </div>

          {/* Quick Share / Utility Controls */}
          <div className="grid grid-cols-3 gap-1.5 mt-1 no-print">
            <button
              onClick={handleCopyLink}
              className="flex flex-col items-center justify-center gap-1 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded text-[10px] font-medium transition"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-400" />
              <span>{copied ? "Copied!" : "Copy"}</span>
            </button>
            <button
              onClick={speakInvoiceText}
              className="flex flex-col items-center justify-center gap-1 py-2 border border-indigo-150 bg-indigo-50/40 hover:bg-indigo-50 text-indigo-700 rounded text-[10px] font-bold transition"
              title="Repeat the audio transaction announcement"
            >
              <Volume2 className="w-3.5 h-3.5 text-indigo-500" />
              <span>Replay Voice</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex flex-col items-center justify-center gap-1 py-2 border border-emerald-150 bg-emerald-50/40 hover:bg-emerald-50 text-emerald-800 rounded text-[10px] font-bold transition"
              title="Trigger high-contrast thermal receipt printer optimization"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-600" />
              <span>Thermal Print</span>
            </button>
          </div>

        </div>

        {/* Auto Reset Timer / Advance Loop Bar */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex flex-col gap-2 no-print">
          <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
            <div className="flex items-center gap-1.5 font-semibold text-slate-700">
              <span className={`w-2 h-2 rounded-full ${autoLoop ? "bg-indigo-600 animate-ping" : "bg-slate-300"}`}></span>
              {autoLoop ? (
                <span>Next customer starts in <span className="text-indigo-600 font-bold">{countdown}s</span></span>
              ) : (
                <span className="text-slate-400">Auto-advance paused</span>
              )}
            </div>
            <button
              onClick={() => setAutoLoop(!autoLoop)}
              className="text-[9px] px-2 py-0.5 rounded border border-slate-200 bg-white hover:bg-slate-100 text-slate-600 transition font-bold"
            >
              {autoLoop ? "Pause Loop" : "Enable Loop"}
            </button>
          </div>
          {autoLoop && (
            <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
              <div 
                className="bg-indigo-600 h-full transition-all duration-1000 ease-linear"
                style={{ width: `${(countdown / 8) * 100}%` }}
              ></div>
            </div>
          )}
        </div>

        {/* Action Bottom Button */}
        <div className="p-5 bg-white border-t border-slate-100 flex justify-end no-print">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold tracking-wider uppercase transition shadow-md hover:shadow-lg flex items-center justify-center gap-2"
          >
            Return to Store Front <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}
